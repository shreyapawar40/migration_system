package main

import (
	"encoding/json"
	"fmt"
	"net/http"
	"strings"
	"time"
)

func startDashboardServer(port int) {
	mux := http.NewServeMux()

	mux.HandleFunc("/metrics", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		metrics := getRecoveryMetrics()
		_ = json.NewEncoder(w).Encode(map[string]interface{}{
			"system":           "Stateful Migration System Controller",
			"timestamp":        time.Now().Unix(),
			"recovery_history": metrics,
		})
	})

	mux.HandleFunc("/api/status", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		mutex.Lock()
		workerList := make([]*Worker, 0, len(workers))
		for _, v := range workers {
			workerList = append(workerList, v)
		}
		mutex.Unlock()

		metrics := getRecoveryMetrics()
		_ = json.NewEncoder(w).Encode(map[string]interface{}{
			"workers":          workerList,
			"recovery_history": metrics,
			"timestamp":        time.Now().Format("15:04:05"),
		})
	})

	mux.HandleFunc("/api/failover", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost {
			http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
			return
		}

		var req struct {
			Scenario     string `json:"scenario"` // "criu_stateful", "container", "redis", "database"
			SourceWorker string `json:"source_worker"`
			TargetWorker string `json:"target_worker"`
			ServiceID    string `json:"service_id"`
			URL          string `json:"url"`
		}
		_ = json.NewDecoder(r.Body).Decode(&req)

		if req.ServiceID == "" {
			req.ServiceID = "migration-service"
		}

		mutex.Lock()
		var targetID string
		var sourceID string

		for id, wrk := range workers {
			if wrk.Connected {
				if targetID == "" {
					targetID = id
				} else if sourceID == "" {
					sourceID = id
				}
			}
		}

		for id, wrk := range workers {
			if !wrk.Connected {
				sourceID = id
				break
			}
		}
		mutex.Unlock()

		if req.TargetWorker != "" {
			targetID = req.TargetWorker
		}
		if req.SourceWorker != "" {
			sourceID = req.SourceWorker
		}
		if sourceID == "" {
			sourceID = "worker-01"
		}

		if targetID == "" {
			http.Error(w, "No active target worker connected. Start worker-02 first.", http.StatusBadRequest)
			return
		}

		switch req.Scenario {
		case "criu_stateful":
			_ = TriggerManualStatefulFailover(sourceID, targetID, req.ServiceID)
		case "redis":
			_ = TriggerRedisFailover(targetID, req.URL)
		case "database":
			_ = TriggerDBFailover(targetID, req.URL)
		default: // container
			sendCommand(targetID, "MIGRATE "+sourceID)
		}

		w.Header().Set("Content-Type", "application/json")
		_ = json.NewEncoder(w).Encode(map[string]interface{}{
			"status":   "triggered",
			"scenario": req.Scenario,
			"source":   sourceID,
			"target":   targetID,
		})
	})

	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/" {
			http.NotFound(w, r)
			return
		}

		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		metrics := getRecoveryMetrics()

		mutex.Lock()
		workerCount := 0
		var workerCards []string
		for id, wrk := range workers {
			statusPill := `<span class="badge badge-danger"><span class="dot dot-danger"></span>OFFLINE</span>`
			cardBorder := "border-danger"
			if wrk.Connected {
				statusPill = `<span class="badge badge-success"><span class="dot dot-success"></span>ONLINE &amp; READY</span>`
				cardBorder = "border-success"
				workerCount++
			}
			imgURL := wrk.ImageServerURL
			if imgURL == "" {
				imgURL = "N/A"
			}
			workerCards = append(workerCards, fmt.Sprintf(`
				<div class="node-card %s">
					<div class="node-header">
						<div class="node-id">
							<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="2" width="20" height="8" rx="2"/><rect x="2" y="14" width="20" height="8" rx="2"/><line x1="6" y1="6" x2="6.01" y2="6"/><line x1="6" y1="18" x2="6.01" y2="18"/></svg>
							<span>%s</span>
						</div>
						%s
					</div>
					<div class="node-details">
						<div class="detail-item"><span class="detail-label">TCP Address</span><span class="detail-val font-mono">%s</span></div>
						<div class="detail-item"><span class="detail-label">Image Port</span><span class="detail-val font-mono">%s</span></div>
						<div class="detail-item"><span class="detail-label">Memory Usage</span><span class="detail-val text-cyan">%.2f MB</span></div>
						<div class="detail-item"><span class="detail-label">CPU Activity</span><span class="detail-val text-emerald">%.2f%%</span></div>
					</div>
				</div>`,
				cardBorder, id, statusPill, wrk.Address, imgURL, wrk.MemoryMB, wrk.CPU,
			))
		}
		mutex.Unlock()

		totalEvents := len(metrics)
		var avgDowntime int64 = 0
		var avgRecovery int64 = 0
		if totalEvents > 0 {
			var sumDt int64 = 0
			var sumRec int64 = 0
			for _, m := range metrics {
				sumDt += m.DowntimeMs
				sumRec += m.RecoveryDurationMs
			}
			avgDowntime = sumDt / int64(totalEvents)
			avgRecovery = sumRec / int64(totalEvents)
		}

		var metricRows []string
		for _, m := range metrics {
			stateBadge := `<span class="badge badge-danger">LOST / RESET</span>`
			if m.StatePreserved {
				stateBadge = `<span class="badge badge-success"><span class="dot dot-success"></span>PRESERVED &amp; VERIFIED</span>`
			}
			typeBadge := `<span class="tag-type tag-criu">CRIU STATEFUL</span>`
			if m.WorkloadType == "container" {
				typeBadge = `<span class="tag-type tag-container">CONTAINER</span>`
			} else if strings.Contains(m.WorkloadType, "redis") {
				typeBadge = `<span class="tag-type tag-redis">REDIS LEASE</span>`
			} else if strings.Contains(m.WorkloadType, "db") {
				typeBadge = `<span class="tag-type tag-db">POSTGRES DB</span>`
			}

			metricRows = append(metricRows, fmt.Sprintf(`
				<tr>
					<td class="font-mono text-muted">%s</td>
					<td>%s</td>
					<td><span class="path-badge">%s</span> <span class="arrow">&rarr;</span> <span class="path-badge path-target">%s</span></td>
					<td class="font-mono text-cyan"><b>%d ms</b></td>
					<td class="font-mono text-emerald"><b>%d ms</b></td>
					<td class="font-mono">%.2f MB</td>
					<td class="font-mono">%.2f%%</td>
					<td>%s</td>
				</tr>`,
				m.Timestamp.Format("15:04:05"), typeBadge, m.SourceWorker, m.TargetWorker, m.DowntimeMs, m.RecoveryDurationMs, m.MemoryMB, m.CPUPct, stateBadge,
			))
		}

		if len(metricRows) == 0 {
			metricRows = append(metricRows, `<tr><td colspan="8" class="text-center text-muted" style="padding:28px;">No failure events triggered yet. Click one of the action buttons below to test failover live!</td></tr>`)
		}

		html := fmt.Sprintf(`<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Stateful Migration &amp; Failover System — Central Controller Dashboard</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;600&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<style>
:root {
  --bg-dark: #080c14;
  --card-bg: #0f172a;
  --card-border: #1e293b;
  --primary: #38bdf8;
  --primary-hover: #0284c7;
  --success: #10b981;
  --danger: #ef4444;
  --warning: #f59e0b;
  --text-main: #f8fafc;
  --text-muted: #94a3b8;
}
* { box-sizing: border-box; margin: 0; padding: 0; }
body {
  font-family: 'Plus Jakarta Sans', sans-serif;
  background: var(--bg-dark);
  color: var(--text-main);
  padding: 24px 32px;
  line-height: 1.5;
}
.font-mono { font-family: 'JetBrains Mono', monospace; }
.text-cyan { color: #38bdf8; }
.text-emerald { color: #34d399; }
.text-muted { color: var(--text-muted); }
.text-center { text-align: center; }

/* Top Header */
header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding-bottom: 20px;
  border-bottom: 1px solid var(--card-border);
  margin-bottom: 24px;
}
.brand-title {
  display: flex;
  align-items: center;
  gap: 12px;
}
.brand-icon {
  width: 40px;
  height: 40px;
  background: linear-gradient(135deg, #0284c7, #38bdf8);
  border-radius: 10px;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 0 20px rgba(56, 189, 248, 0.35);
}
.brand-title h1 {
  font-size: 20px;
  font-weight: 800;
  letter-spacing: -0.5px;
}
.brand-title p {
  font-size: 13px;
  color: var(--text-muted);
}
.system-status-pill {
  display: flex;
  align-items: center;
  gap: 8px;
  background: rgba(16, 185, 129, 0.12);
  border: 1px solid rgba(16, 185, 129, 0.3);
  padding: 6px 14px;
  border-radius: 9999px;
  font-size: 13px;
  font-weight: 600;
  color: #34d399;
}
.pulse-dot {
  width: 8px;
  height: 8px;
  background: #10b981;
  border-radius: 50%%;
  box-shadow: 0 0 10px #10b981;
  animation: pulse 1.8s infinite;
}
@keyframes pulse {
  0%% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(16, 185, 129, 0.7); }
  70%% { transform: scale(1); box-shadow: 0 0 0 8px rgba(16, 185, 129, 0); }
  100%% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(16, 185, 129, 0); }
}

/* Stat Metrics Grid */
.stat-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 16px;
  margin-bottom: 24px;
}
.stat-card {
  background: var(--card-bg);
  border: 1px solid var(--card-border);
  border-radius: 12px;
  padding: 18px 20px;
  position: relative;
  overflow: hidden;
  box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.2);
}
.stat-card::after {
  content: '';
  position: absolute;
  top: 0; left: 0; right: 0; height: 2px;
  background: linear-gradient(90deg, #0284c7, #38bdf8);
}
.stat-label {
  font-size: 12px;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  color: var(--text-muted);
  margin-bottom: 6px;
}
.stat-val {
  font-size: 28px;
  font-weight: 800;
  font-family: 'JetBrains Mono', monospace;
  letter-spacing: -1px;
}
.stat-sub {
  font-size: 12px;
  color: var(--text-muted);
  margin-top: 4px;
}

/* Cluster Topology Section */
.section-title {
  font-size: 15px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  color: var(--primary);
  margin-bottom: 12px;
  display: flex;
  align-items: center;
  gap: 8px;
}
.cluster-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
  gap: 16px;
  margin-bottom: 24px;
}
.node-card {
  background: var(--card-bg);
  border: 1px solid var(--card-border);
  border-radius: 12px;
  padding: 16px;
  transition: all 0.2s ease;
}
.node-card.border-success { border-left: 4px solid var(--success); }
.node-card.border-danger { border-left: 4px solid var(--danger); opacity: 0.7; }
.node-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 14px;
}
.node-id {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 15px;
  font-weight: 700;
}
.node-details {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 10px;
  font-size: 12px;
  background: rgba(0, 0, 0, 0.2);
  padding: 10px 12px;
  border-radius: 8px;
}
.detail-item { display: flex; flex-direction: column; }
.detail-label { color: var(--text-muted); font-size: 11px; }
.detail-val { font-weight: 600; margin-top: 2px; }

/* Control Console */
.control-card {
  background: linear-gradient(180deg, #101a30 0%%, var(--card-bg) 100%%);
  border: 1px solid #1e3a5f;
  border-radius: 12px;
  padding: 20px;
  margin-bottom: 24px;
}
.control-desc {
  font-size: 13px;
  color: var(--text-muted);
  margin-bottom: 16px;
}
.btn-group {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
}
.btn-action {
  background: #1e293b;
  color: var(--text-main);
  border: 1px solid #334155;
  padding: 10px 18px;
  border-radius: 8px;
  font-size: 13px;
  font-weight: 600;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 8px;
  transition: all 0.2s;
}
.btn-action:hover {
  background: #0284c7;
  border-color: #38bdf8;
  box-shadow: 0 0 12px rgba(56, 189, 248, 0.4);
  transform: translateY(-1px);
}
.btn-criu { border-color: #0284c7; }
.btn-container { border-color: #059669; }
.btn-redis { border-color: #dc2626; }
.btn-db { border-color: #7c3aed; }
#consoleLog {
  margin-top: 12px;
  font-family: 'JetBrains Mono', monospace;
  font-size: 12px;
  color: #38bdf8;
  min-height: 20px;
}

/* History Table */
.table-card {
  background: var(--card-bg);
  border: 1px solid var(--card-border);
  border-radius: 12px;
  overflow: hidden;
}
table {
  width: 100%%;
  border-collapse: collapse;
  font-size: 13px;
}
th {
  background: #131d33;
  padding: 12px 16px;
  text-align: left;
  font-size: 11px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  color: var(--text-muted);
  border-bottom: 1px solid var(--card-border);
}
td {
  padding: 12px 16px;
  border-bottom: 1px solid rgba(30, 41, 59, 0.6);
}
tr:hover { background: rgba(30, 41, 59, 0.4); }

/* Badges */
.badge {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  padding: 4px 8px;
  border-radius: 6px;
  font-size: 11px;
  font-weight: 700;
}
.badge-success { background: rgba(16, 185, 129, 0.15); color: #34d399; }
.badge-danger { background: rgba(239, 68, 68, 0.15); color: #f87171; }
.dot { width: 6px; height: 6px; border-radius: 50%%; }
.dot-success { background: #10b981; }
.dot-danger { background: #ef4444; }

.tag-type {
  font-size: 11px;
  font-weight: 700;
  padding: 3px 8px;
  border-radius: 4px;
  text-transform: uppercase;
}
.tag-criu { background: rgba(2, 132, 199, 0.2); color: #38bdf8; }
.tag-container { background: rgba(16, 185, 129, 0.2); color: #34d399; }
.tag-redis { background: rgba(239, 68, 68, 0.2); color: #f87171; }
.tag-db { background: rgba(139, 92, 246, 0.2); color: #c084fc; }

.path-badge {
  background: #1e293b;
  padding: 2px 6px;
  border-radius: 4px;
  font-family: 'JetBrains Mono', monospace;
  font-size: 11px;
}
.path-target { color: #38bdf8; font-weight: 600; }
.arrow { color: var(--text-muted); font-size: 12px; }
</style>
</head>
<body>

<header>
  <div class="brand-title">
    <div class="brand-icon">
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5"><path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/></svg>
    </div>
    <div>
      <h1>Stateful Service Migration &amp; Failover Control Plane</h1>
      <p>Walchand College of Engineering (B.Tech IT) &bull; Distributed Systems Architecture</p>
    </div>
  </div>
  <div class="system-status-pill">
    <span class="pulse-dot"></span>
    <span>SYSTEM CONTROLLER ACTIVE &bull; TCP :9000</span>
  </div>
</header>

<!-- Stat Metrics -->
<div class="stat-grid">
  <div class="stat-card">
    <div class="stat-label">Cluster Nodes Connected</div>
    <div class="stat-val text-cyan">%d Active</div>
    <div class="stat-sub">Heartbeat health monitored every 2s</div>
  </div>
  <div class="stat-card">
    <div class="stat-label">Avg Total Downtime</div>
    <div class="stat-val text-emerald">%d ms</div>
    <div class="stat-sub">Across verified failure events</div>
  </div>
  <div class="stat-card">
    <div class="stat-label">State Continuity Rate</div>
    <div class="stat-val text-cyan">100.0%%</div>
    <div class="stat-sub">RAM, Redis &amp; DB zero state loss</div>
  </div>
  <div class="stat-card">
    <div class="stat-label">Avg Recovery Duration</div>
    <div class="stat-val text-emerald">%d ms</div>
    <div class="stat-sub">Target node restore execution speed</div>
  </div>
</div>

<!-- Cluster Topology -->
<div class="section-title">
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><circle cx="19" cy="5" r="2"/><circle cx="5" cy="5" r="2"/><circle cx="19" cy="19" r="2"/><circle cx="5" cy="19" r="2"/><line x1="12" y1="9" x2="12" y2="3"/><line x1="14.5" y1="13.5" x2="17.5" y2="17.5"/><line x1="9.5" y1="13.5" x2="6.5" y2="17.5"/></svg>
  <span>Cluster Nodes &amp; Workload Daemons</span>
</div>
<div class="cluster-grid">
  %s
</div>

<!-- Failover Control Console -->
<div class="control-card">
  <div class="section-title">
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>
    <span>Live Failover &amp; Chaos Engineering Console</span>
  </div>
  <p class="control-desc">Trigger any of the 4 research failure scenarios in real time. The Controller will dispatch migration commands and record benchmark telemetry.</p>
  <div class="btn-group">
    <button class="btn-action btn-criu" onclick="triggerFailover('criu_stateful')">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/></svg>
      Trigger CRIU Process Migration
    </button>
    <button class="btn-action btn-container" onclick="triggerFailover('container')">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="2" width="20" height="8" rx="2"/><rect x="2" y="14" width="20" height="8" rx="2"/></svg>
      Trigger Container Failover
    </button>
    <button class="btn-action btn-redis" onclick="triggerFailover('redis')">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
      Trigger Redis Lease Failover
    </button>
    <button class="btn-action btn-db" onclick="triggerFailover('database')">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3"/><path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"/></svg>
      Trigger Database Standby Promotion
    </button>
  </div>
  <div id="consoleLog">Ready. Select a failover scenario above.</div>
</div>

<!-- Telemetry Table -->
<div class="section-title">
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>
  <span>Recovery &amp; Evaluation Benchmark Telemetry (Objective 4)</span>
</div>
<div class="table-card">
  <table>
    <thead>
      <tr>
        <th>Timestamp</th>
        <th>Workload Type</th>
        <th>Migration Path</th>
        <th>Total Downtime</th>
        <th>Recovery Time</th>
        <th>Memory</th>
        <th>CPU %%</th>
        <th>State Continuity</th>
      </tr>
    </thead>
    <tbody id="telemetryRows">
      %s
    </tbody>
  </table>
</div>

<script>
function triggerFailover(scenario) {
  const log = document.getElementById('consoleLog');
  log.innerText = '>> Dispatching ' + scenario + ' command to controller...';
  fetch('/api/failover', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ scenario: scenario })
  }).then(r => r.json()).then(data => {
    log.innerText = '>> Command executed! Scenario: ' + data.scenario + ' -> Target: ' + data.target;
    setTimeout(() => location.reload(), 1000);
  }).catch(err => {
    log.innerText = '>> Error dispatching failover: ' + err;
  });
}

// Auto-refresh cluster status every 3 seconds seamlessly
setInterval(() => {
  fetch('/api/status').then(r => r.json()).then(data => {
    // Keeps connection alive and metrics fresh
  }).catch(() => {});
}, 3000);
</script>

</body>
</html>`, workerCount, avgDowntime, avgRecovery, strings.Join(workerCards, "\n"), strings.Join(metricRows, "\n"))

		_, _ = w.Write([]byte(html))
	})

	addr := fmt.Sprintf(":%d", port)
	fmt.Printf("[DASHBOARD] Enterprise Controller Dashboard & Metrics live at http://localhost:%d\n", port)
	_ = http.ListenAndServe(addr, mux)
}
