package main

import (
	"fmt"
	"time"
)

func startFailureDetector() {
	ticker := time.NewTicker(2 * time.Second)
	defer ticker.Stop()

	for range ticker.C {
		now := time.Now()

		type failedWorker struct {
			id            string
			lastHeartbeat time.Time
		}

		var failed []failedWorker

		mutex.Lock()

		for id, worker := range workers {
			if worker.Connected &&
				now.Sub(worker.LastHeartbeat) > 10*time.Second {

				worker.Connected = false
				failureTimestamps[id] = now

				failed = append(failed, failedWorker{
					id:            id,
					lastHeartbeat: worker.LastHeartbeat,
				})
			}
		}

		mutex.Unlock()

		for _, worker := range failed {
			reportFailure(worker.id, worker.lastHeartbeat)
		}
	}
}

func reportFailure(workerID string, lastHeartbeat time.Time) {
	fmt.Println()
	fmt.Println("====================================")
	fmt.Println("FAILURE DETECTED")
	fmt.Println("Node:", workerID)
	fmt.Println("Last heartbeat:", lastHeartbeat.Format(time.RFC3339))
	fmt.Println("====================================")

	startRecovery(workerID)
}
