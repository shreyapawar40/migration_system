package main

func main() {
	go startServer()
	go startDashboardServer(9001)
	startFailureDetector()
}
