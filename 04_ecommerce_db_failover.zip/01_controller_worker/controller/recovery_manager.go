package main

import (
	"fmt"
	"sync"
	"time"
)

var (
	pendingRecoveries   = make(map[string]bool)
	recoveryManagerLock sync.Mutex
)

func startRecovery(sourceWorkerID string) {
	recoveryManagerLock.Lock()

	if pendingRecoveries[sourceWorkerID] {
		recoveryManagerLock.Unlock()
		return
	}

	mutex.Lock()

	var targetWorkerID string
	var imageURL string

	for id, worker := range workers {
		if id != sourceWorkerID &&
			worker.Connected &&
			worker.Conn != nil {
			targetWorkerID = id
			break
		}
	}

	// Look up if source worker had an active checkpoint image
	if img, ok := lastCheckpoints[sourceWorkerID]; ok && img != "" {
		imageURL = img
	} else if srcWorker, ok := workers[sourceWorkerID]; ok && srcWorker.ImageServerURL != "" {
		imageURL = srcWorker.ImageServerURL
	}

	mutex.Unlock()

	fmt.Println()
	fmt.Println("========================================")
	fmt.Println("        RECOVERY MANAGER")
	fmt.Println("========================================")
	fmt.Println("Source:", sourceWorkerID)

	if targetWorkerID == "" {
		pendingRecoveries[sourceWorkerID] = true
		recoveryManagerLock.Unlock()

		fmt.Println("Target: NONE")
		fmt.Println("Strategy: RECOVERY PENDING")
		fmt.Println("Waiting for another worker to connect...")
		fmt.Println("========================================")
		return
	}

	// Mark recovery as pending/in progress.
	pendingRecoveries[sourceWorkerID] = true
	recoveryManagerLock.Unlock()

	fmt.Println("Target:", targetWorkerID)

	if imageURL != "" {
		fmt.Println("Strategy: CRIU STATEFUL MIGRATION")
		fmt.Printf("Image URL: %s\n", imageURL)
		fmt.Println("========================================")
		cmd := fmt.Sprintf("MIGRATE_STATEFUL %s %s migration-service", sourceWorkerID, imageURL)
		sendCommand(targetWorkerID, cmd)
	} else {
		fmt.Println("Strategy: SERVICE RECOVERY (CONTAINER)")
		fmt.Println("========================================")
		sendCommand(targetWorkerID, "MIGRATE "+sourceWorkerID)
	}
}

func retryPendingRecoveries(targetWorkerID string) {
	recoveryManagerLock.Lock()

	var sourceWorkerID string

	for sourceID := range pendingRecoveries {
		if sourceID != targetWorkerID {
			sourceWorkerID = sourceID
			break
		}
	}

	if sourceWorkerID != "" {
		delete(pendingRecoveries, sourceWorkerID)
	}

	recoveryManagerLock.Unlock()

	if sourceWorkerID != "" {
		fmt.Println("Retrying pending recovery for:", sourceWorkerID)
		startRecovery(sourceWorkerID)
	}
}

func completeRecovery(sourceWorkerID string) {
	recoveryManagerLock.Lock()
	delete(pendingRecoveries, sourceWorkerID)
	recoveryManagerLock.Unlock()

	fmt.Println("Recovery tracking cleared for:", sourceWorkerID)
}

// TriggerManualStatefulFailover manually triggers a CRIU stateful migration across workers.
func TriggerManualStatefulFailover(sourceID string, targetID string, serviceID string) error {
	mutex.Lock()
	targetWorker, targetExists := workers[targetID]
	imgURL := lastCheckpoints[sourceID]
	if imgURL == "" {
		if src, ok := workers[sourceID]; ok {
			imgURL = src.ImageServerURL
		}
	}
	mutex.Unlock()

	if !targetExists || !targetWorker.Connected {
		return fmt.Errorf("target worker %s is not connected", targetID)
	}

	failureTimestamps[sourceID] = time.Now()
	cmd := fmt.Sprintf("MIGRATE_STATEFUL %s %s %s", sourceID, imgURL, serviceID)
	sendCommand(targetID, cmd)
	return nil
}

// TriggerRedisFailover triggers promotion of shadow rate limiter to primary lease.
func TriggerRedisFailover(targetWorkerID string, secondaryURL string) error {
	mutex.Lock()
	targetWorker, exists := workers[targetWorkerID]
	mutex.Unlock()

	if !exists || !targetWorker.Connected {
		return fmt.Errorf("worker %s is not connected", targetWorkerID)
	}

	cmd := fmt.Sprintf("FAILOVER_REDIS %s", secondaryURL)
	sendCommand(targetWorkerID, cmd)
	return nil
}

// TriggerDBFailover triggers PostgreSQL standby promotion.
func TriggerDBFailover(targetWorkerID string, standbyHost string) error {
	mutex.Lock()
	targetWorker, exists := workers[targetWorkerID]
	mutex.Unlock()

	if !exists || !targetWorker.Connected {
		return fmt.Errorf("worker %s is not connected", targetWorkerID)
	}

	cmd := fmt.Sprintf("FAILOVER_DB %s", standbyHost)
	sendCommand(targetWorkerID, cmd)
	return nil
}
