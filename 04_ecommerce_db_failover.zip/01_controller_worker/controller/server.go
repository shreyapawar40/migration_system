package main

import (
	"bufio"
	"fmt"
	"net"
	"strconv"
	"strings"
	"sync"
	"time"
)

var connectionMutex sync.Mutex

func getOutboundIP() string {
	conn, err := net.Dial("udp", "8.8.8.8:80")
	if err == nil {
		defer conn.Close()
		localAddr, ok := conn.LocalAddr().(*net.UDPAddr)
		if ok && localAddr != nil {
			return localAddr.IP.String()
		}
	}
	addrs, err := net.InterfaceAddrs()
	if err == nil {
		for _, addr := range addrs {
			if ipnet, ok := addr.(*net.IPNet); ok && !ipnet.IP.IsLoopback() {
				if ipnet.IP.To4() != nil {
					return ipnet.IP.String()
				}
			}
		}
	}
	return "127.0.0.1"
}

func startServer() {
	listener, err := net.Listen("tcp", ":9000")
	if err != nil {
		fmt.Println("Failed to start controller:", err)
		return
	}
	defer listener.Close()

	localIP := getOutboundIP()
	fmt.Println("========================================")
	fmt.Println("        MIGRATION SYSTEM")
	fmt.Println("          CONTROLLER")
	fmt.Println("========================================")
	fmt.Println("Listening on TCP port 9000 (all interfaces)...")
	fmt.Printf("[NETWORK] Local Controller IP: %s\n", localIP)
	fmt.Printf("[NETWORK] Dashboard: http://localhost:9001 or http://%s:9001\n", localIP)
	fmt.Printf("[NETWORK] Cross-PC Command for other laptops:\n")
	fmt.Printf("          .\\worker.exe worker-02 %s:9000\n", localIP)
	fmt.Println("----------------------------------------")

	for {
		conn, err := listener.Accept()
		if err != nil {
			fmt.Println("Failed to accept worker:", err)
			continue
		}

		go handleWorker(conn)
	}
}

func handleWorker(conn net.Conn) {
	defer conn.Close()

	reader := bufio.NewReader(conn)
	workerID := ""
	registered := false

	fmt.Println("Worker connected:", conn.RemoteAddr())

	for {
		message, err := reader.ReadString('\n')
		if err != nil {
			break
		}

		message = strings.TrimSpace(message)
		if message == "" {
			continue
		}

		switch {
		case strings.HasPrefix(message, "CONNECT "):
			parts := strings.Fields(strings.TrimPrefix(message, "CONNECT "))
			if len(parts) == 0 || parts[0] == "" {
				fmt.Fprintln(conn, "ERROR Invalid worker ID")
				return
			}

			workerID = parts[0]
			imageURL := ""
			if len(parts) > 1 {
				imageURL = parts[1]
			}

			// Automatically normalize localhost in imageURL if worker connects from a remote PC
			remoteHost, _, splitErr := net.SplitHostPort(conn.RemoteAddr().String())
			if splitErr == nil && remoteHost != "127.0.0.1" && remoteHost != "::1" && remoteHost != "" {
				if strings.Contains(imageURL, "localhost") {
					imageURL = strings.Replace(imageURL, "localhost", remoteHost, 1)
				} else if strings.Contains(imageURL, "127.0.0.1") {
					imageURL = strings.Replace(imageURL, "127.0.0.1", remoteHost, 1)
				}
			}

			mutex.Lock()
			workers[workerID] = &Worker{
				ID:             workerID,
				Address:        conn.RemoteAddr().String(),
				ImageServerURL: imageURL,
				LastHeartbeat:  time.Now(),
				Connected:      true,
				Conn:           conn,
			}
			mutex.Unlock()

			registered = true

			fmt.Printf("Worker registered: %s (Image URL: %s)\n", workerID, imageURL)
			fmt.Fprintln(conn, "ACK")

			retryPendingRecoveries(workerID)

			sendCommand(workerID, "STATUS")
			sendCommand(workerID, "DOCKER_STATUS")
			sendCommand(workerID, "SERVICE_STATUS")
			sendCommand(workerID, "GET_METRICS")

		case message == "HEARTBEAT":
			mutex.Lock()

			accepted := false
			if worker, exists := workers[workerID]; exists &&
				worker.Conn == conn &&
				worker.Connected {
				worker.LastHeartbeat = time.Now()
				accepted = true
			}

			mutex.Unlock()

			if accepted {
				fmt.Println("Heartbeat:", workerID)
				fmt.Fprintln(conn, "ACK")
			}

		case message == "STATUS_OK":
			fmt.Println()
			fmt.Println("====================================")
			fmt.Println("STATUS RESPONSE RECEIVED")
			fmt.Println("Worker:", workerID)
			fmt.Println("Status: OK")
			fmt.Println("====================================")

		case message == "DOCKER_STATUS_OK":
			fmt.Println()
			fmt.Println("====================================")
			fmt.Println("DOCKER STATUS")
			fmt.Println("Worker:", workerID)
			fmt.Println("Docker: RUNNING")
			fmt.Println("====================================")

		case message == "DOCKER_STATUS_FAILED":
			fmt.Println("Docker is not running on worker:", workerID)

		case message == "SERVICE_RUNNING":
			fmt.Println()
			fmt.Println("====================================")
			fmt.Println("SERVICE STATUS")
			fmt.Println("Worker:", workerID)
			fmt.Println("Service: migration-service")
			fmt.Println("Status: RUNNING")
			fmt.Println("====================================")

		case message == "SERVICE_STOPPED":
			fmt.Println()
			fmt.Println("====================================")
			fmt.Println("SERVICE STATUS")
			fmt.Println("Worker:", workerID)
			fmt.Println("Service: migration-service")
			fmt.Println("Status: STOPPED")
			fmt.Println("====================================")

		case message == "SERVICE_NOT_FOUND":
			fmt.Println("Service migration-service not found on worker:", workerID)

		case strings.HasPrefix(message, "CHECKPOINT_OK "):
			// Format: CHECKPOINT_OK <serviceID> <imageURL> <size> <dur>
			parts := strings.Fields(strings.TrimPrefix(message, "CHECKPOINT_OK "))
			if len(parts) >= 2 {
				svc := parts[0]
				imgURL := parts[1]
				mutex.Lock()
				lastCheckpoints[svc] = imgURL
				lastCheckpoints[workerID] = imgURL
				mutex.Unlock()
				fmt.Printf("[CONTROLLER] Checkpoint registered for %s on %s: %s\n", svc, workerID, imgURL)
			}

		case strings.HasPrefix(message, "METRICS "):
			parts := strings.Fields(strings.TrimPrefix(message, "METRICS "))
			mutex.Lock()
			if w, ok := workers[workerID]; ok {
				for _, p := range parts {
					kv := strings.SplitN(p, "=", 2)
					if len(kv) == 2 {
						if kv[0] == "cpu" {
							w.CPU, _ = strconv.ParseFloat(kv[1], 64)
						} else if kv[0] == "mem_mb" {
							w.MemoryMB, _ = strconv.ParseFloat(kv[1], 64)
						}
					}
				}
			}
			mutex.Unlock()

		case strings.HasPrefix(message, "RECOVERY_STARTED "):
			source := strings.TrimSpace(
				strings.TrimPrefix(message, "RECOVERY_STARTED "),
			)
			fmt.Println("Recovery started on", workerID, "for source:", source)

		case strings.HasPrefix(message, "RECOVERY_COMPLETED "):
			raw := strings.TrimPrefix(message, "RECOVERY_COMPLETED ")
			tokens := strings.Fields(raw)
			source := "unknown"
			if len(tokens) > 0 {
				source = tokens[0]
			}

			completeRecovery(source)

			// Parse metrics params: type=... duration_ms=... downtime_ms=... mem_mb=... cpu_pct=...
			recType := "container"
			var durMs int64 = 0
			var dtMs int64 = 0
			var memMB float64 = 0.0
			var cpuPct float64 = 0.0
			statePreserved := true

			for _, t := range tokens[1:] {
				kv := strings.SplitN(t, "=", 2)
				if len(kv) == 2 {
					switch kv[0] {
					case "type":
						recType = kv[1]
					case "duration_ms":
						durMs, _ = strconv.ParseInt(kv[1], 10, 64)
					case "downtime_ms":
						dtMs, _ = strconv.ParseInt(kv[1], 10, 64)
					case "mem_mb":
						memMB, _ = strconv.ParseFloat(kv[1], 64)
					case "cpu_pct":
						cpuPct, _ = strconv.ParseFloat(kv[1], 64)
					case "resumed_state":
						statePreserved = (kv[1] != "" && kv[1] != "0")
					}
				}
			}

			// If downtime wasn't sent, compute from failure detection timestamp
			mutex.Lock()
			if failTime, ok := failureTimestamps[source]; ok && dtMs == 0 {
				dtMs = time.Since(failTime).Milliseconds()
			}
			mutex.Unlock()
			if dtMs == 0 {
				dtMs = durMs
			}

			// Record evaluation metric
			metric := RecoveryMetricRecord{
				ID:                 fmt.Sprintf("rec_%d", time.Now().UnixNano()),
				Timestamp:          time.Now(),
				FailureType:        "worker_failure",
				WorkloadType:       recType,
				SourceWorker:       source,
				TargetWorker:       workerID,
				DowntimeMs:         dtMs,
				RecoveryDurationMs: durMs,
				MemoryMB:           memMB,
				CPUPct:             cpuPct,
				StatePreserved:     statePreserved,
				Status:             "SUCCESS",
				Details:            fmt.Sprintf("Recovery of %s onto %s completed successfully", source, workerID),
			}
			recordRecoveryMetric(metric)

			fmt.Println()
			fmt.Println("====================================")
			fmt.Println("RECOVERY COMPLETED")
			fmt.Println("Source:", source)
			fmt.Println("Target:", workerID)
			fmt.Printf("Workload Type: %s\n", recType)
			fmt.Printf("Downtime:      %d ms\n", dtMs)
			fmt.Printf("Recovery Time: %d ms\n", durMs)
			fmt.Printf("Memory:        %.2f MB\n", memMB)
			fmt.Printf("CPU:           %.2f%%\n", cpuPct)
			fmt.Printf("State Preserved: %v\n", statePreserved)
			fmt.Println("Status: SUCCESS")
			fmt.Println("====================================")

		case strings.HasPrefix(message, "RECOVERY_FAILED "):
			source := strings.TrimSpace(
				strings.TrimPrefix(message, "RECOVERY_FAILED "),
			)

			metric := RecoveryMetricRecord{
				ID:           fmt.Sprintf("rec_fail_%d", time.Now().UnixNano()),
				Timestamp:    time.Now(),
				FailureType:  "recovery_failed",
				SourceWorker: source,
				TargetWorker: workerID,
				Status:       "FAILED",
				Details:      fmt.Sprintf("Recovery attempt on target %s failed", workerID),
			}
			recordRecoveryMetric(metric)

			fmt.Println()
			fmt.Println("====================================")
			fmt.Println("RECOVERY FAILED")
			fmt.Println("Source:", source)
			fmt.Println("Target:", workerID)
			fmt.Println("Recovery remains pending.")
			fmt.Println("====================================")

		default:
			fmt.Println("Unknown message from", workerID+":", message)
		}
	}

	shouldRecover := false
	var lastHeartbeat time.Time

	if registered {
		mutex.Lock()

		if worker, exists := workers[workerID]; exists &&
			worker.Conn == conn &&
			worker.Connected {
			worker.Connected = false
			lastHeartbeat = worker.LastHeartbeat
			failureTimestamps[workerID] = time.Now()
			shouldRecover = true
		}

		mutex.Unlock()

		fmt.Println("Worker connection lost:", workerID)

		if shouldRecover {
			reportFailure(workerID, lastHeartbeat)
		}
	}
}

func sendCommand(workerID string, command string) {
	mutex.Lock()

	worker, exists := workers[workerID]
	if !exists || !worker.Connected || worker.Conn == nil {
		mutex.Unlock()
		fmt.Println("Cannot send command; worker unavailable:", workerID)
		return
	}

	conn := worker.Conn
	mutex.Unlock()

	connectionMutex.Lock()
	_, err := fmt.Fprintln(conn, command)
	connectionMutex.Unlock()

	if err != nil {
		fmt.Println("Failed to send command to", workerID, ":", err)
		return
	}

	fmt.Println("Command sent to", workerID, ":", command)
}
