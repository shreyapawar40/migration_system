package main

import (
	"net"
	"sync"
	"time"
)

// RecoveryMetricRecord captures evaluation metrics for a failover / migration event.
type RecoveryMetricRecord struct {
	ID                 string    `json:"id"`
	Timestamp          time.Time `json:"timestamp"`
	FailureType        string    `json:"failure_type"`
	WorkloadType       string    `json:"workload_type"`
	SourceWorker       string    `json:"source_worker"`
	TargetWorker       string    `json:"target_worker"`
	DowntimeMs         int64     `json:"downtime_ms"`
	RecoveryDurationMs int64     `json:"recovery_duration_ms"`
	MemoryMB           float64   `json:"memory_mb"`
	CPUPct             float64   `json:"cpu_pct"`
	StatePreserved     bool      `json:"state_preserved"`
	Status             string    `json:"status"`
	Details            string    `json:"details"`
}

// Worker represents a connected node in the migration cluster.
type Worker struct {
	ID             string    `json:"id"`
	Address        string    `json:"address"`
	ImageServerURL string    `json:"image_server_url"`
	LastHeartbeat  time.Time `json:"last_heartbeat"`
	Connected      bool      `json:"connected"`
	Conn           net.Conn  `json:"-"`
	WorkloadState  string    `json:"workload_state"`
	CPU            float64   `json:"cpu"`
	MemoryMB       float64   `json:"memory_mb"`
}

var (
	workers         = make(map[string]*Worker)
	lastCheckpoints = make(map[string]string) // workerID -> imageURL
	mutex           sync.Mutex

	recoveryHistory     []RecoveryMetricRecord
	recoveryHistoryLock sync.RWMutex
	failureTimestamps   = make(map[string]time.Time) // workerID -> detected failure time
)

func recordRecoveryMetric(m RecoveryMetricRecord) {
	recoveryHistoryLock.Lock()
	defer recoveryHistoryLock.Unlock()
	recoveryHistory = append(recoveryHistory, m)
}

func getRecoveryMetrics() []RecoveryMetricRecord {
	recoveryHistoryLock.RLock()
	defer recoveryHistoryLock.RUnlock()
	copied := make([]RecoveryMetricRecord, len(recoveryHistory))
	copy(copied, recoveryHistory)
	return copied
}
