package main

import (
	"bufio"
	"fmt"
	"net"
	"os"
	"strings"
)

const defaultControllerAddress = "localhost:9000"

var (
	workerID          = "worker-01"
	controllerAddress = defaultControllerAddress
)

// connectToController returns the same buffered reader used to read ACK.
func connectToController() (net.Conn, *bufio.Reader) {
	if len(os.Args) > 1 && strings.TrimSpace(os.Args[1]) != "" {
		workerID = strings.TrimSpace(os.Args[1])
	}

	controllerAddress = strings.TrimSpace(os.Getenv("CONTROLLER_ADDR"))
	if controllerAddress == "" && len(os.Args) > 2 {
		controllerAddress = strings.TrimSpace(os.Args[2])
	}
	if controllerAddress == "" {
		controllerAddress = defaultControllerAddress
	}

	fmt.Println("========================================")
	fmt.Println("        MIGRATION SYSTEM")
	fmt.Println("             WORKER")
	fmt.Println("========================================")
	fmt.Println("Worker ID:", workerID)
	fmt.Println("Controller address:", controllerAddress)
	if globalStatefulMgr != nil {
		fmt.Println("Image server URL:", globalStatefulMgr.ImageServerURL)
	}

	conn, err := net.Dial("tcp", controllerAddress)
	if err != nil {
		fmt.Println("Failed to connect to controller:", err)
		return nil, nil
	}

	reader := bufio.NewReader(conn)
	imageURL := ""
	if globalStatefulMgr != nil {
		imageURL = globalStatefulMgr.ImageServerURL
	}

	connectMsg := fmt.Sprintf("CONNECT %s %s\n", workerID, imageURL)
	if _, err := fmt.Fprint(conn, connectMsg); err != nil {
		fmt.Println("Failed to register with controller:", err)
		_ = conn.Close()
		return nil, nil
	}

	response, err := reader.ReadString('\n')
	if err != nil {
		fmt.Println("Controller registration failed:", err)
		_ = conn.Close()
		return nil, nil
	}

	response = strings.TrimSpace(response)
	fmt.Println("Controller:", response)
	if response != "ACK" {
		fmt.Println("Controller rejected worker registration")
		_ = conn.Close()
		return nil, nil
	}

	return conn, reader
}
