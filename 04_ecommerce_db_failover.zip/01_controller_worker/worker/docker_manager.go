package main

import (
	"fmt"
	"os/exec"
	"strings"
)

const serviceName = "migration-service"

// dockerStatus checks whether Docker Engine is available.
func dockerStatus() bool {
	cmd := exec.Command("docker", "info")
	err := cmd.Run()

	return err == nil
}

// serviceStatus checks the current state of the migration service.
func serviceStatus() string {
	output, err := exec.Command(
		"docker",
		"inspect",
		"-f",
		"{{.State.Status}}",
		serviceName,
	).CombinedOutput()

	if err != nil {
		return "SERVICE_NOT_FOUND"
	}

	status := strings.TrimSpace(string(output))

	switch status {
	case "running":
		return "SERVICE_RUNNING"

	case "created", "exited":
		return "SERVICE_STOPPED"

	default:
		return "SERVICE_STOPPED"
	}
}

// recoverService starts the existing container or creates it
// if it does not exist. It verifies the result before returning success.
func recoverService() error {
	fmt.Println()
	fmt.Println("========================================")
	fmt.Println("       DOCKER SERVICE RECOVERY")
	fmt.Println("========================================")
	fmt.Println("Service:", serviceName)

	if !dockerStatus() {
		return fmt.Errorf(
			"Docker Engine is unavailable; start Docker Desktop first",
		)
	}

	status := serviceStatus()

	switch status {
	case "SERVICE_RUNNING":
		fmt.Println("Container is already running.")

	case "SERVICE_STOPPED":
		fmt.Println("Starting the existing container...")

		output, err := exec.Command(
			"docker",
			"start",
			serviceName,
		).CombinedOutput()

		if err != nil {
			return fmt.Errorf(
				"failed to start container: %s",
				strings.TrimSpace(string(output)),
			)
		}

		fmt.Println(strings.TrimSpace(string(output)))

	case "SERVICE_NOT_FOUND":
		fmt.Println("Container not found. Creating a new container...")

		output, err := exec.Command(
			"docker",
			"run",
			"-d",
			"--name",
			serviceName,
			"-p",
			"8080:80",
			"nginx",
		).CombinedOutput()

		if err != nil {
			return fmt.Errorf(
				"failed to create container: %s",
				strings.TrimSpace(string(output)),
			)
		}

		fmt.Println(strings.TrimSpace(string(output)))
	}

	// Verify that Docker reports the container as running.
	if serviceStatus() != "SERVICE_RUNNING" {
		return fmt.Errorf(
			"recovery verification failed: container is not running",
		)
	}

	// Verify that Nginx configuration is valid inside the container.
	output, err := exec.Command(
		"docker",
		"exec",
		serviceName,
		"nginx",
		"-t",
	).CombinedOutput()

	fmt.Print(string(output))

	if err != nil {
		return fmt.Errorf(
			"Nginx verification failed: %s",
			strings.TrimSpace(string(output)),
		)
	}

	// Final state check after verification.
	if serviceStatus() != "SERVICE_RUNNING" {
		return fmt.Errorf(
			"container stopped during recovery verification",
		)
	}

	fmt.Println("Container status: RUNNING")
	fmt.Println("Nginx configuration: VALID")
	fmt.Println("Recovery verification: SUCCESS")
	fmt.Println("========================================")

	return nil
}
