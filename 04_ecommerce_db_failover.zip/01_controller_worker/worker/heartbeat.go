package main

import (
	"fmt"
	"net"
	"time"
)

func startHeartbeat(conn net.Conn) {

	ticker := time.NewTicker(3 * time.Second)

	defer ticker.Stop()

	for range ticker.C {

		fmt.Fprintln(conn, "HEARTBEAT")

		fmt.Println("Heartbeat sent")
	}
}
