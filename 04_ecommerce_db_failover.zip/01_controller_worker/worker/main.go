package main

import (
	"os"
	"strconv"
	"strings"
)

func main() {
	imagePort := 9101
	if portStr := os.Getenv("IMAGE_PORT"); portStr != "" {
		if p, err := strconv.Atoi(portStr); err == nil {
			imagePort = p
		}
	} else if len(os.Args) > 1 {
		id := os.Args[1]
		if strings.HasSuffix(id, "02") || strings.HasSuffix(id, "2") {
			imagePort = 9102
		} else if strings.HasSuffix(id, "03") || strings.HasSuffix(id, "3") {
			imagePort = 9103
		}
	}

	initStatefulRecoveryManager(imagePort)

	conn, reader := connectToController()
	if conn == nil || reader == nil {
		return
	}
	defer conn.Close()

	go startCommandHandler(conn, reader)
	startHeartbeat(conn)
}
