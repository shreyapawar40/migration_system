package main

import (
	"fmt"
	"runtime"
	"time"
)

// ResourceMetrics contains current host resource consumption metrics.
type ResourceMetrics struct {
	AllocMB      float64 `json:"alloc_mb"`
	TotalAllocMB float64 `json:"total_alloc_mb"`
	SysMB        float64 `json:"sys_mb"`
	NumGC        uint32  `json:"num_gc"`
	NumGoroutine int     `json:"num_goroutine"`
	CPUPct       float64 `json:"cpu_pct"`
	Timestamp    int64   `json:"timestamp"`
}

var lastCPUSampleTime time.Time

func getResourceMetrics() ResourceMetrics {
	var m runtime.MemStats
	runtime.ReadMemStats(&m)

	now := time.Now()
	lastCPUSampleTime = now

	// Estimate CPU utilization based on active goroutines and GOMAXPROCS
	goroutines := runtime.NumGoroutine()
	maxProcs := runtime.GOMAXPROCS(0)
	cpuEst := (float64(goroutines) / float64(maxProcs*10)) * 100.0
	if cpuEst > 100.0 {
		cpuEst = 95.0
	}
	if cpuEst < 1.0 {
		cpuEst = 1.2
	}

	return ResourceMetrics{
		AllocMB:      float64(m.Alloc) / (1024.0 * 1024.0),
		TotalAllocMB: float64(m.TotalAlloc) / (1024.0 * 1024.0),
		SysMB:        float64(m.Sys) / (1024.0 * 1024.0),
		NumGC:        m.NumGC,
		NumGoroutine: goroutines,
		CPUPct:       cpuEst,
		Timestamp:    now.Unix(),
	}
}

func formatMetricsString(m ResourceMetrics) string {
	return fmt.Sprintf("cpu=%.2f mem_mb=%.2f goroutines=%d", m.CPUPct, m.AllocMB, m.NumGoroutine)
}
