# CRIU Stateful Migration Module

## Overview
This module implements real Checkpoint/Restore In Userspace (CRIU), stateful application memory snapshotting, compressed image packaging (`.tar.gz`), network image migration, target process restoration, and health verification.

## Architecture
```
+-------------------------------------------------------------+
|                      SOURCE NODE                            |
|  1. Capture PID / Workload State                            |
|  2. Checkpoint (`criu dump` / Docker Checkpoint / State)    |
|  3. Validate images (`inventory.img`, `core.img`, metadata)  |
|  4. Package into `.tar.gz` transfer bundle                  |
+------------------------------+------------------------------+
                               |
                               | (TCP / HTTP Image Transfer)
                               v
+-------------------------------------------------------------+
|                      TARGET NODE                            |
|  5. Receive & Unpack archive bundle                         |
|  6. Verify metadata and checksum integrity                  |
|  7. Restore process (`criu restore` / Docker Restore)        |
|  8. Verify process health & state continuity                |
|  9. Acknowledge recovery & report metrics (downtime/CPU/RAM)|
+-------------------------------------------------------------+
```

## Linux Kernel & Container Prerequisites for Native CRIU
To run native kernel-level CRIU on Linux / WSL2:
1. Kernel options: `CONFIG_CHECKPOINT_RESTORE=y`, `CONFIG_NAMESPACES=y`
2. Install CRIU: `sudo apt-get install -y criu`
3. If using Docker container checkpointing:
   - Enable experimental mode in `/etc/docker/daemon.json`:
     ```json
     { "experimental": true }
     ```
   - Restart Docker: `sudo systemctl restart docker`
   - Run container with `--security-opt seccomp=unconfined`

## Commands & Execution
From directory `02_criu_experiment/criu`:

### 1. Run Demo
Runs a stateful in-memory process, checkpoints it, triggers failure, restores it, and validates state continuity:
```bash
go run . demo
```

### 2. Run Performance Benchmark
Measures recovery time, downtime, image size, and memory usage across multiple trials:
```bash
go run . benchmark
```

### 3. Checkpoint an Arbitrary Process
```bash
go run . checkpoint -pid <PID> -dir /path/to/images
```

### 4. Restore an Image Archive
```bash
go run . restore -archive /path/to/archive.tar.gz
```
