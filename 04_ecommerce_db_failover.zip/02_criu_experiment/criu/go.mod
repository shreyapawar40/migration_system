module criu-experiment

go 1.22
