package main

import (
	"flag"
	"fmt"
	"os"
	"runtime"
	"strconv"
	"sync"
	"time"
)

func main() {
	if len(os.Args) < 2 {
		printUsage()
		return
	}

	subcommand := os.Args[1]

	switch subcommand {
	case "demo":
		runDemo()
	case "benchmark":
		runBenchmark()
	case "checkpoint":
		runCheckpointCLI(os.Args[2:])
	case "restore":
		runRestoreCLI(os.Args[2:])
	default:
		fmt.Printf("Unknown command: %s\n", subcommand)
		printUsage()
	}
}

func printUsage() {
	fmt.Println("=================================================================")
	fmt.Println("             CRIU STATEFUL MIGRATION ENGINE")
	fmt.Println("=================================================================")
	fmt.Println("Usage:")
	fmt.Println("  go run . demo           # Run end-to-end stateful checkpoint/restore demo")
	fmt.Println("  go run . benchmark      # Run performance benchmark (Downtime/Recovery/CPU/Memory)")
	fmt.Println("  go run . checkpoint -pid <pid> -dir <imageDir>")
	fmt.Println("  go run . restore -dir <imageDir>")
	fmt.Println("=================================================================")
}

// StatefulProcess simulates an active in-memory workload with state continuity
type StatefulProcess struct {
	mu           sync.Mutex
	Counter      int
	Transactions map[string]float64
	Running      bool
}

func (p *StatefulProcess) Start() {
	p.mu.Lock()
	p.Running = true
	p.Transactions = make(map[string]float64)
	p.mu.Unlock()

	go func() {
		for {
			p.mu.Lock()
			if !p.Running {
				p.mu.Unlock()
				return
			}
			p.Counter++
			p.Transactions[fmt.Sprintf("tx_%d", p.Counter)] = float64(p.Counter) * 10.5
			p.mu.Unlock()
			time.Sleep(50 * time.Millisecond)
		}
	}()
}

func (p *StatefulProcess) Stop() {
	p.mu.Lock()
	p.Running = false
	p.mu.Unlock()
}

func (p *StatefulProcess) DumpState() map[string]string {
	p.mu.Lock()
	defer p.mu.Unlock()
	return map[string]string{
		"counter":      strconv.Itoa(p.Counter),
		"transactions": strconv.Itoa(len(p.Transactions)),
		"status":       "active",
	}
}

func runDemo() {
	fmt.Println("=================================================================")
	fmt.Println(" [OBJECTIVE 3] CRIU STATEFUL CHECKPOINT & RESTORE VERIFICATION")
	fmt.Println("=================================================================")

	fmt.Printf("OS: %s | Arch: %s | Native CRIU: %v\n", runtime.GOOS, runtime.GOARCH, IsCRIUAvailable())

	// Step 1: Start stateful process
	fmt.Println("\n[1] Starting stateful in-memory process...")
	proc := &StatefulProcess{}
	proc.Start()
	time.Sleep(300 * time.Millisecond)

	initialState := proc.DumpState()
	fmt.Printf("    Process running. Current State: Counter=%s, TxCount=%s\n",
		initialState["counter"], initialState["transactions"])

	// Step 2: Checkpoint process state
	fmt.Println("\n[2] Executing CRIU Checkpoint...")
	imgDir := fmt.Sprintf("./test_criu_image_%d", time.Now().UnixNano())
	defer os.RemoveAll(imgDir)

	ckptResult, err := Checkpoint(CheckpointConfig{
		PID:         os.Getpid(),
		ImageDir:    imgDir,
		CustomState: initialState,
	})
	if err != nil {
		fmt.Printf("Checkpoint failed: %v\n", err)
		return
	}
	defer os.Remove(ckptResult.ArchivePath)

	fmt.Printf("    Checkpoint Success!\n")
	fmt.Printf("    - Method:           %s\n", ckptResult.Method)
	fmt.Printf("    - Checkpoint Time:  %s (%d ms)\n", ckptResult.Duration, ckptResult.DurationMs)
	fmt.Printf("    - Image Size:       %d bytes (%.2f KB)\n", ckptResult.ImageSizeBytes, float64(ckptResult.ImageSizeBytes)/1024.0)
	fmt.Printf("    - Archive Bundle:   %s\n", ckptResult.ArchivePath)

	// Step 3: Simulate failure / crash
	fmt.Println("\n[3] Simulating Failure (Process Termination)...")
	failureTime := time.Now()
	proc.Stop()
	savedCounter := initialState["counter"]
	fmt.Printf("    Process killed at %s. State at crash: Counter=%s\n",
		failureTime.Format("15:04:05.000"), savedCounter)

	time.Sleep(100 * time.Millisecond) // Simulate brief detection gap

	// Step 4: Restore from checkpoint archive
	fmt.Println("\n[4] Executing CRIU Target Restoration...")
	restoreResult, err := Restore(RestoreConfig{
		ArchivePath: ckptResult.ArchivePath,
		FailureTime: failureTime,
	})
	if err != nil {
		fmt.Printf("Restore failed: %v\n", err)
		return
	}

	fmt.Printf("    Restore Success!\n")
	fmt.Printf("    - Method:           %s\n", restoreResult.Method)
	fmt.Printf("    - Restore Time:     %s (%d ms)\n", restoreResult.Duration, restoreResult.DurationMs)
	fmt.Printf("    - Total Downtime:   %s (%d ms)\n", restoreResult.Downtime, restoreResult.DowntimeMs)
	fmt.Printf("    - Memory Usage:     %.2f MB\n", float64(restoreResult.MemoryUsageBytes)/(1024.0*1024.0))

	// Step 5: Verify State Continuity
	fmt.Println("\n[5] Verifying State Continuity & Correctness...")
	restoredCounter := restoreResult.RestoredState["counter"]
	fmt.Printf("    - Expected Counter: %s\n", savedCounter)
	fmt.Printf("    - Restored Counter: %s\n", restoredCounter)

	if restoredCounter == savedCounter && restoredCounter != "0" {
		fmt.Println("    [VERIFIED] State preservation confirmed! No state lost.")
	} else {
		fmt.Println("    [FAILED] State mismatch or reset.")
	}

	fmt.Println("=================================================================")
}

func runBenchmark() {
	fmt.Println("=================================================================")
	fmt.Println(" [OBJECTIVE 4] CRIU BENCHMARK: DOWNTIME, RECOVERY & RESOURCES")
	fmt.Println("=================================================================")

	const iterations = 5
	var totalDowntimeMs int64
	var totalRecoveryMs int64
	var totalImageBytes int64

	fmt.Println("Trial | Checkpoint (ms) | Restore (ms) | Downtime (ms) | Image (KB) | Memory (MB)")
	fmt.Println("-----------------------------------------------------------------------------")

	for i := 1; i <= iterations; i++ {
		proc := &StatefulProcess{}
		proc.Start()
		time.Sleep(100 * time.Millisecond)
		state := proc.DumpState()

		imgDir := fmt.Sprintf("./bench_img_%d", i)
		ckptResult, err := Checkpoint(CheckpointConfig{
			PID:         os.Getpid(),
			ImageDir:    imgDir,
			CustomState: state,
		})
		if err != nil {
			fmt.Printf("Trial %d failed checkpoint: %v\n", i, err)
			proc.Stop()
			continue
		}

		failTime := time.Now()
		proc.Stop()

		time.Sleep(50 * time.Millisecond)

		restResult, err := Restore(RestoreConfig{
			ArchivePath: ckptResult.ArchivePath,
			FailureTime: failTime,
		})
		if err != nil {
			fmt.Printf("Trial %d failed restore: %v\n", i, err)
			_ = os.RemoveAll(imgDir)
			_ = os.Remove(ckptResult.ArchivePath)
			continue
		}

		totalDowntimeMs += restResult.DowntimeMs
		totalRecoveryMs += restResult.DurationMs
		totalImageBytes += ckptResult.ImageSizeBytes

		fmt.Printf("%5d | %15d | %12d | %13d | %10.1f | %11.2f\n",
			i,
			ckptResult.DurationMs,
			restResult.DurationMs,
			restResult.DowntimeMs,
			float64(ckptResult.ImageSizeBytes)/1024.0,
			float64(restResult.MemoryUsageBytes)/(1024.0*1024.0),
		)

		_ = os.RemoveAll(imgDir)
		_ = os.Remove(ckptResult.ArchivePath)
	}

	fmt.Println("-----------------------------------------------------------------------------")
	fmt.Printf("Average Recovery Time: %.2f ms\n", float64(totalRecoveryMs)/float64(iterations))
	fmt.Printf("Average Total Downtime: %.2f ms\n", float64(totalDowntimeMs)/float64(iterations))
	fmt.Printf("Average Checkpoint Image Size: %.2f KB\n", float64(totalImageBytes)/(float64(iterations)*1024.0))
	fmt.Println("=================================================================")
}

func runCheckpointCLI(args []string) {
	fs := flag.NewFlagSet("checkpoint", flag.ExitOnError)
	pid := fs.Int("pid", 0, "Target process PID")
	dir := fs.String("dir", "./criu_images", "Image directory")
	fs.Parse(args)

	if *pid <= 0 {
		fmt.Println("Error: valid -pid is required")
		return
	}

	res, err := Checkpoint(CheckpointConfig{
		PID:      *pid,
		ImageDir: *dir,
	})
	if err != nil {
		fmt.Printf("Checkpoint failed: %v\n", err)
		return
	}

	fmt.Printf("Checkpoint created: %s (%d ms, %d bytes)\n", res.ArchivePath, res.DurationMs, res.ImageSizeBytes)
}

func runRestoreCLI(args []string) {
	fs := flag.NewFlagSet("restore", flag.ExitOnError)
	archive := fs.String("archive", "", "Path to image archive .tar.gz")
	dir := fs.String("dir", "", "Path to image directory")
	fs.Parse(args)

	res, err := Restore(RestoreConfig{
		ArchivePath: *archive,
		ImageDir:    *dir,
	})
	if err != nil {
		fmt.Printf("Restore failed: %v\n", err)
		return
	}

	fmt.Printf("Restore completed successfully in %d ms (Downtime: %d ms)\n", res.DurationMs, res.DowntimeMs)
}
