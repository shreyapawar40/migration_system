package main

// Resotre wraps Restore to maintain backwards compatibility with the legacy filename typo.
func Resotre(cfg RestoreConfig) (*RestoreResult, error) {
	return Restore(cfg)
}
