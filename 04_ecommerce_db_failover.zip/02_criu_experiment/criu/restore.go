package main

import (
	"archive/tar"
	"compress/gzip"
	"fmt"
	"io"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"time"
)

// RestoreConfig defines parameters for a CRIU / stateful restore operation.
type RestoreConfig struct {
	ImageDir       string        `json:"image_dir"`
	ArchivePath    string        `json:"archive_path,omitempty"`
	ContainerID    string        `json:"container_id,omitempty"`
	CheckpointName string        `json:"checkpoint_name,omitempty"`
	TcpEstablished bool          `json:"tcp_established"`
	ShellJob       bool          `json:"shell_job"`
	HealthURL      string        `json:"health_url,omitempty"`
	FailureTime    time.Time     `json:"failure_time,omitempty"`
}

// RestoreResult holds output metrics from the restore operation.
type RestoreResult struct {
	PID              int               `json:"pid"`
	ContainerID      string            `json:"container_id,omitempty"`
	Duration         time.Duration     `json:"duration"`
	DurationMs       int64             `json:"duration_ms"`
	Downtime         time.Duration     `json:"downtime"`
	DowntimeMs       int64             `json:"downtime_ms"`
	MemoryUsageBytes uint64            `json:"memory_usage_bytes"`
	Method           string            `json:"method"`
	RestoredState    map[string]string `json:"restored_state,omitempty"`
	Success          bool              `json:"success"`
}

// Restore executes restoration of a process or container from a CRIU image.
func Restore(cfg RestoreConfig) (*RestoreResult, error) {
	startTime := time.Now()

	// If archive was provided, unpack it first
	if cfg.ArchivePath != "" {
		if cfg.ImageDir == "" {
			cfg.ImageDir = filepath.Join(os.TempDir(), fmt.Sprintf("criu_restore_%d", time.Now().UnixNano()))
		}
		if err := os.MkdirAll(cfg.ImageDir, 0755); err != nil {
			return nil, fmt.Errorf("failed to create restore directory: %w", err)
		}
		if err := ExtractImageArchive(cfg.ArchivePath, cfg.ImageDir); err != nil {
			return nil, fmt.Errorf("failed to extract image archive: %w", err)
		}
	}

	// Verify checkpoint validity
	meta, err := VerifyCheckpoint(cfg.ImageDir)
	if err != nil {
		return nil, fmt.Errorf("checkpoint verification failed: %w", err)
	}

	result := &RestoreResult{
		Method:        meta.Method,
		RestoredState: meta.CustomState,
	}

	// 1. Restore Docker container if applicable
	if cfg.ContainerID != "" {
		ckptName := cfg.CheckpointName
		if ckptName == "" {
			ckptName = "ckpt_latest"
		}
		cmd := exec.Command("docker", "start", "--checkpoint", ckptName, "--checkpoint-dir", cfg.ImageDir, cfg.ContainerID)
		output, err := cmd.CombinedOutput()
		if err == nil {
			result.Method = "docker_checkpoint"
			result.ContainerID = cfg.ContainerID
			fmt.Printf("[CRIU-DOCKER] Restored container %s successfully: %s\n", cfg.ContainerID, string(output))
		} else {
			fmt.Printf("[CRIU-DOCKER] Docker checkpoint restore note: %s (falling back to process restore)\n", string(output))
		}
	}

	// 2. Restore native CRIU if available
	if result.Method == "criu_native" && IsCRIUAvailable() {
		args := []string{"restore", "-D", cfg.ImageDir}
		if cfg.ShellJob || meta.Method == "criu_native" {
			args = append(args, "--shell-job")
		}
		if cfg.TcpEstablished || meta.TcpEstablished {
			args = append(args, "--tcp-established")
		}

		cmd := exec.Command("criu", args...)
		output, err := cmd.CombinedOutput()
		if err != nil {
			return nil, fmt.Errorf("criu restore failed: %s (output: %s)", err, string(output))
		}
		result.PID = meta.PID
		fmt.Printf("[CRIU-NATIVE] Process %d restored successfully via CRIU\n", result.PID)
	}

	// 3. Stateful application restore verification
	if result.PID == 0 {
		result.PID = meta.PID
		if result.Method == "" {
			result.Method = "stateful_snapshot"
		}
		fmt.Printf("[CRIU-STATE] Restored stateful application context (Original PID: %d, Keys: %d)\n", meta.PID, len(meta.CustomState))
	}

	// Optional health endpoint verification
	if cfg.HealthURL != "" {
		verified, err := VerifyProcessHealth(cfg.HealthURL, 5*time.Second)
		if !verified || err != nil {
			return nil, fmt.Errorf("health verification failed post-restore: %v", err)
		}
		fmt.Printf("[CRIU-HEALTH] Health verified on %s\n", cfg.HealthURL)
	}

	var m runtime.MemStats
	runtime.ReadMemStats(&m)
	result.MemoryUsageBytes = m.Alloc
	result.Duration = time.Since(startTime)
	result.DurationMs = result.Duration.Milliseconds()

	if !cfg.FailureTime.IsZero() {
		result.Downtime = time.Since(cfg.FailureTime)
		result.DowntimeMs = result.Downtime.Milliseconds()
	} else {
		result.Downtime = result.Duration
		result.DowntimeMs = result.DurationMs
	}
	result.Success = true

	return result, nil
}

// ExtractImageArchive unpacks a tar.gz bundle into the target directory.
func ExtractImageArchive(archivePath string, targetDir string) error {
	tarFile, err := os.Open(archivePath)
	if err != nil {
		return err
	}
	defer tarFile.Close()

	gzReader, err := gzip.NewReader(tarFile)
	if err != nil {
		return err
	}
	defer gzReader.Close()

	tarReader := tar.NewReader(gzReader)

	for {
		header, err := tarReader.Next()
		if err == io.EOF {
			break
		}
		if err != nil {
			return err
		}

		destPath := filepath.Join(targetDir, header.Name)
		switch header.Typeflag {
		case tar.TypeDir:
			if err := os.MkdirAll(destPath, 0755); err != nil {
				return err
			}
		case tar.TypeReg:
			if err := os.MkdirAll(filepath.Dir(destPath), 0755); err != nil {
				return err
			}
			outFile, err := os.Create(destPath)
			if err != nil {
				return err
			}
			if _, err := io.Copy(outFile, tarReader); err != nil {
				outFile.Close()
				return err
			}
			outFile.Close()
		}
	}

	return nil
}

// VerifyProcessHealth pings an HTTP health check endpoint until it responds OK or timeout expires.
func VerifyProcessHealth(healthURL string, timeout time.Duration) (bool, error) {
	client := &http.Client{Timeout: 500 * time.Millisecond}
	deadline := time.Now().Add(timeout)

	for time.Now().Before(deadline) {
		resp, err := client.Get(healthURL)
		if err == nil {
			defer resp.Body.Close()
			if resp.StatusCode == http.StatusOK {
				return true, nil
			}
		}
		time.Sleep(100 * time.Millisecond)
	}

	return false, fmt.Errorf("endpoint %s failed to respond 200 OK within %s", healthURL, timeout)
}
