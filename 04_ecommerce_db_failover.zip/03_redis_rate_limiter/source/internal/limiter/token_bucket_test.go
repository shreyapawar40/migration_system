package limiter

import (
	"context"
	"testing"
	"time"

	"github.com/redis/go-redis/v9"
)

func getTestRedisClient(t *testing.T) *redis.Client {
	client := redis.NewClient(&redis.Options{
		Addr:        "localhost:6379",
		DialTimeout: 200 * time.Millisecond,
	})

	ctx, cancel := context.WithTimeout(context.Background(), 500*time.Millisecond)
	defer cancel()

	if err := client.Ping(ctx).Err(); err != nil {
		t.Skipf("Skipping test: local Redis at localhost:6379 is not running (%v)", err)
		return nil
	}
	return client
}

func TestTokenBucket(t *testing.T) {
	client := getTestRedisClient(t)
	if client == nil {
		return
	}
	defer client.Close()

	ctx := context.Background()
	key := "rate_limit:test_client:/test"

	client.Del(ctx, key)
	bucket := NewTokenBucket(client, 5, 1)

	// First request should be allowed
	result, err := bucket.Allow(ctx, key)
	if err != nil {
		t.Fatal(err)
	}

	if !result.Allowed {
		t.Fatal("expected first request to be allowed")
	}

	if result.Remaining >= 5 {
		t.Fatalf("expected remaining tokens < 5, got %f", result.Remaining)
	}

	client.Del(ctx, key)
}

func TestTokenBucketRejectsAfterCapacity(t *testing.T) {
	client := getTestRedisClient(t)
	if client == nil {
		return
	}
	defer client.Close()

	ctx := context.Background()
	key := "rate_limit:test_rejection:/test"

	client.Del(ctx, key)
	bucket := NewTokenBucket(client, 5, 1)

	// Consume all 5 tokens
	for i := 0; i < 5; i++ {
		result, err := bucket.Allow(ctx, key)
		if err != nil {
			t.Fatal(err)
		}
		if !result.Allowed {
			t.Fatalf("request %d should be allowed", i+1)
		}
	}

	// 6th request should be rejected
	result, err := bucket.Allow(ctx, key)
	if err != nil {
		t.Fatal(err)
	}

	if result.Allowed {
		t.Fatal("expected 6th request to be rejected")
	}

	client.Del(ctx, key)
}
