package store

import (
	"context"
	"testing"
	"time"

	"github.com/redis/go-redis/v9"
)

func getTestRedisStore(t *testing.T) *RedisStore {
	store := NewRedisStore("localhost", "6379")
	store.Client.Options().DialTimeout = 200 * time.Millisecond

	ctx, cancel := context.WithTimeout(context.Background(), 500*time.Millisecond)
	defer cancel()

	if err := store.Ping(ctx); err != nil {
		t.Skipf("Skipping test: Redis server at localhost:6379 is not running (%v)", err)
		return nil
	}
	return store
}

func TestPrimaryLeaseRenewal(t *testing.T) {
	store := getTestRedisStore(t)
	if store == nil {
		return
	}
	defer store.Client.Close()

	ctx := context.Background()

	// Clean previous ownership.
	_ = store.Client.Del(ctx, "rate_limiter:primary").Err()

	instanceID := "test-primary"

	// Acquire the lease.
	acquired, err := store.AcquirePrimary(ctx, instanceID)
	if err != nil {
		t.Fatal(err)
	}
	if !acquired {
		t.Fatal("failed to acquire primary lease")
	}

	// Verify ownership.
	owner, err := store.GetPrimary(ctx)
	if err != nil {
		t.Fatal(err)
	}
	if owner != instanceID {
		t.Fatalf("expected owner %s, got %s", instanceID, owner)
	}

	// Wait a little so TTL decreases.
	time.Sleep(1 * time.Second)

	ttlBefore, err := store.Client.TTL(ctx, "rate_limiter:primary").Result()
	if err != nil {
		t.Fatal(err)
	}

	// Renew the lease.
	renewed, err := store.RenewPrimary(ctx, instanceID)
	if err != nil {
		t.Fatal(err)
	}
	if !renewed {
		t.Fatal("failed to renew primary lease")
	}

	// Check TTL after renewal.
	ttlAfter, err := store.Client.TTL(ctx, "rate_limiter:primary").Result()
	if err != nil {
		t.Fatal(err)
	}

	if ttlAfter <= ttlBefore {
		t.Fatalf("expected TTL to increase: before=%v after=%v", ttlBefore, ttlAfter)
	}

	_ = store.Client.Del(ctx, "rate_limiter:primary").Err()
}

func TestPrimaryLeaseRelease(t *testing.T) {
	store := getTestRedisStore(t)
	if store == nil {
		return
	}
	defer store.Client.Close()

	ctx := context.Background()
	_ = store.Client.Del(ctx, "rate_limiter:primary").Err()

	instanceID := "test-release-instance"
	_, _ = store.AcquirePrimary(ctx, instanceID)

	err := store.ReleasePrimary(ctx, instanceID)
	if err != nil {
		t.Fatal(err)
	}

	owner, err := store.GetPrimary(ctx)
	if err != redis.Nil {
		t.Fatalf("expected nil after release, got owner=%s err=%v", owner, err)
	}
}
