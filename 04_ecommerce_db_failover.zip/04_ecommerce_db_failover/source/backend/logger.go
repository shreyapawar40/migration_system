package main

import (
	"fmt"
	"os"
	"strings"
	"sync"
	"time"
)

var logMutex sync.Mutex

// logEvent writes one line to /logs/cascade.log AND stdout.
// Format: TIMESTAMP | LAYER | INSTANCE | EVENT_TYPE | LEVEL | MESSAGE | k=v k=v ...
func logEvent(layer, instance, eventType, level, message string, kv ...string) {
	logMutex.Lock()
	defer logMutex.Unlock()

	ts := time.Now().Format("2006-01-02 15:04:05.000")
	parts := []string{ts, layer, instance, eventType, level, message}

	if len(kv) > 0 {
		var pairs []string
		for i := 0; i+1 < len(kv); i += 2 {
			pairs = append(pairs, kv[i]+"="+kv[i+1])
		}
		parts = append(parts, strings.Join(pairs, " "))
	}

	line := strings.Join(parts, " | ") + "\n"

	// Write to shared file
	f, err := os.OpenFile("/logs/cascade.log", os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0666)
	if err == nil {
		f.WriteString(line)
		f.Close()
	} else {
		// If can't write to file, at least log to stderr
		fmt.Fprintf(os.Stderr, "log write failed: %v\n", err)
	}

	// Also print to stdout so docker logs capture it
	fmt.Print(line)
}
