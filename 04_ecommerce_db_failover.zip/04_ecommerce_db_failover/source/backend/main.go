package main

import (
	"database/sql"
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"os"
	"strconv"
	"strings"
	"sync/atomic"
	"time"

	_ "github.com/lib/pq"
)

var db *sql.DB

// Instance identity — set via env var
var instanceName = getEnv("INSTANCE_NAME", "backend-primary")

// Counters
var requestCount int64 = 0
var dbQueryCount int64 = 0

// Thresholds
const requestThreshold = 6
const dbThreshold = 10

func getEnv(key, def string) string {
	if v := os.Getenv(key); v != "" {
		return v
	}
	return def
}

type User struct {
	ID    int    `json:"id"`
	Email string `json:"email"`
}

type Product struct {
	ID          int     `json:"id"`
	Name        string  `json:"name"`
	Description string  `json:"description"`
	Price       float64 `json:"price"`
	Stock       int     `json:"stock"`
}

type CartItem struct {
	ID        int     `json:"id"`
	UserID    int     `json:"user_id"`
	ProductID int     `json:"product_id"`
	Quantity  int     `json:"quantity"`
	Name      string  `json:"name"`
	Price     float64 `json:"price"`
}

type Order struct {
	ID        int     `json:"id"`
	UserID    int     `json:"user_id"`
	Total     float64 `json:"total"`
	Status    string  `json:"status"`
	CreatedAt string  `json:"created_at"`
}

func enableCORS(w http.ResponseWriter) {
	w.Header().Set("Access-Control-Allow-Origin", "*")
	w.Header().Set("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
	w.Header().Set("Access-Control-Allow-Headers", "Content-Type, Authorization")
}

func writeJSON(w http.ResponseWriter, status int, data interface{}) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	json.NewEncoder(w).Encode(data)
}

func writeError(w http.ResponseWriter, status int, msg string) {
	writeJSON(w, status, map[string]string{"error": msg})
}

// ---- Request counter + threshold ----
func bumpRequest(path string) bool {
	n := atomic.AddInt64(&requestCount, 1)

	logEvent("BACKEND", instanceName, "request_received", "INFO",
		fmt.Sprintf("req %d of %d", n, requestThreshold),
		"path", path,
		"count", fmt.Sprintf("%d", n),
		"threshold", fmt.Sprintf("%d", requestThreshold))

	if int(n) >= requestThreshold {
		logEvent("BACKEND", instanceName, "threshold_reached", "WARN",
			"request capacity hit, exiting to trigger failover",
			"threshold", fmt.Sprintf("%d", requestThreshold))

		logEvent("BACKEND", instanceName, "shutting_down", "CRITICAL",
			"exiting to trigger failover",
			"reason", "request_threshold",
			"threshold", fmt.Sprintf("%d", requestThreshold))

		// Exit after a short delay so logs flush
		go func() {
			time.Sleep(200 * time.Millisecond)
			os.Exit(1)
		}()
		return false
	}
	return true
}

// ---- DB query counter ----
func bumpDBQuery(query string) {
	n := atomic.AddInt64(&dbQueryCount, 1)

	logEvent("BACKEND", instanceName, "db_query", "INFO",
		query,
		"query_count", fmt.Sprintf("%d", n),
		"threshold", fmt.Sprintf("%d", dbThreshold))

	if int(n) >= dbThreshold {
		logEvent("BACKEND", instanceName, "db_threshold_reached", "WARN",
			"query capacity hit — watcher will fail over DB",
			"threshold", fmt.Sprintf("%d", dbThreshold))
	}
}

// ---- Handlers ----

func registerHandler(w http.ResponseWriter, r *http.Request) {
	enableCORS(w)
	if r.Method == "OPTIONS" {
		return
	}
	if !bumpRequest("/api/register") {
		writeError(w, 503, "backend shutting down")
		return
	}
	var req struct {
		Email    string `json:"email"`
		Password string `json:"password"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeError(w, 400, "invalid body")
		return
	}
	if req.Email == "" || req.Password == "" {
		writeError(w, 400, "email and password required")
		return
	}
	bumpDBQuery("INSERT INTO users")
	var id int
	err := db.QueryRow(
		"INSERT INTO users (email, password_hash) VALUES ($1, $2) RETURNING id",
		req.Email, req.Password,
	).Scan(&id)
	if err != nil {
		log.Printf("register error: %v", err)
		writeError(w, 500, "could not register")
		return
	}
	writeJSON(w, 201, User{ID: id, Email: req.Email})
}

func loginHandler(w http.ResponseWriter, r *http.Request) {
	enableCORS(w)
	if r.Method == "OPTIONS" {
		return
	}
	if !bumpRequest("/api/login") {
		writeError(w, 503, "backend shutting down")
		return
	}
	var req struct {
		Email    string `json:"email"`
		Password string `json:"password"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeError(w, 400, "invalid body")
		return
	}
	bumpDBQuery("SELECT users WHERE email")
	var user User
	var pw string
	err := db.QueryRow(
		"SELECT id, email, password_hash FROM users WHERE email=$1",
		req.Email,
	).Scan(&user.ID, &user.Email, &pw)
	if err != nil {
		writeError(w, 401, "invalid credentials")
		return
	}
	if pw != req.Password {
		writeError(w, 401, "invalid credentials")
		return
	}
	writeJSON(w, 200, user)
}

func productsHandler(w http.ResponseWriter, r *http.Request) {
	enableCORS(w)
	if r.Method == "OPTIONS" {
		return
	}
	if !bumpRequest("/api/products") {
		writeError(w, 503, "backend shutting down")
		return
	}
	search := r.URL.Query().Get("search")
	var rows *sql.Rows
	var err error
	if search == "" {
		bumpDBQuery("SELECT products")
		rows, err = db.Query("SELECT id, name, description, price, stock FROM products ORDER BY id")
	} else {
		bumpDBQuery("SELECT products WHERE name ILIKE")
		rows, err = db.Query(
			"SELECT id, name, description, price, stock FROM products WHERE name ILIKE $1 ORDER BY id",
			"%"+search+"%",
		)
	}
	if err != nil {
		writeError(w, 500, "query failed")
		return
	}
	defer rows.Close()
	var items []Product
	for rows.Next() {
		var p Product
		rows.Scan(&p.ID, &p.Name, &p.Description, &p.Price, &p.Stock)
		items = append(items, p)
	}
	writeJSON(w, 200, items)
}

func cartHandler(w http.ResponseWriter, r *http.Request) {
	enableCORS(w)
	if r.Method == "OPTIONS" {
		return
	}
	if !bumpRequest("/api/cart") {
		writeError(w, 503, "backend shutting down")
		return
	}
	switch r.Method {
	case "POST":
		var req struct {
			UserID    int `json:"user_id"`
			ProductID int `json:"product_id"`
			Quantity  int `json:"quantity"`
		}
		if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
			writeError(w, 400, "invalid body")
			return
		}
		if req.Quantity <= 0 {
			req.Quantity = 1
		}
		bumpDBQuery("INSERT INTO carts")
		_, err := db.Exec(
			"INSERT INTO carts (user_id, product_id, quantity) VALUES ($1, $2, $3)",
			req.UserID, req.ProductID, req.Quantity,
		)
		if err != nil {
			log.Printf("cart insert error: %v", err)
			writeError(w, 500, "could not add to cart")
			return
		}
		writeJSON(w, 201, map[string]string{"status": "added"})
	case "GET":
		uidStr := r.URL.Query().Get("user_id")
		uid, _ := strconv.Atoi(uidStr)
		bumpDBQuery("SELECT carts JOIN products")
		rows, err := db.Query(`
			SELECT c.id, c.user_id, c.product_id, c.quantity, p.name, p.price
			FROM carts c JOIN products p ON p.id = c.product_id
			WHERE c.user_id = $1 ORDER BY c.id`, uid)
		if err != nil {
			writeError(w, 500, "query failed")
			return
		}
		defer rows.Close()
		var items []CartItem
		for rows.Next() {
			var it CartItem
			rows.Scan(&it.ID, &it.UserID, &it.ProductID, &it.Quantity, &it.Name, &it.Price)
			items = append(items, it)
		}
		writeJSON(w, 200, items)
	}
}

func removeCartHandler(w http.ResponseWriter, r *http.Request) {
	enableCORS(w)
	if r.Method == "OPTIONS" {
		return
	}
	if !bumpRequest("/api/cart/{id}") {
		writeError(w, 503, "backend shutting down")
		return
	}
	idStr := strings.TrimPrefix(r.URL.Path, "/api/cart/")
	id, _ := strconv.Atoi(idStr)
	bumpDBQuery("DELETE FROM carts")
	_, err := db.Exec("DELETE FROM carts WHERE id=$1", id)
	if err != nil {
		writeError(w, 500, "delete failed")
		return
	}
	writeJSON(w, 200, map[string]string{"status": "removed"})
}

func orderHandler(w http.ResponseWriter, r *http.Request) {
	enableCORS(w)
	if r.Method == "OPTIONS" {
		return
	}
	if !bumpRequest("/api/order") {
		writeError(w, 503, "backend shutting down")
		return
	}
	var req struct {
		UserID int `json:"user_id"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeError(w, 400, "invalid body")
		return
	}

	bumpDBQuery("BEGIN transaction")
	tx, err := db.Begin()
	if err != nil {
		writeError(w, 500, "tx begin failed")
		return
	}
	defer tx.Rollback()

	bumpDBQuery("SELECT carts JOIN products FOR ORDER")
	rows, err := tx.Query(`
		SELECT c.product_id, c.quantity, p.price
		FROM carts c JOIN products p ON p.id = c.product_id
		WHERE c.user_id = $1`, req.UserID)
	if err != nil {
		writeError(w, 500, "cart query failed")
		return
	}
	var items []struct {
		ProductID int
		Quantity  int
		Price     float64
	}
	total := 0.0
	for rows.Next() {
		var it struct {
			ProductID int
			Quantity  int
			Price     float64
		}
		rows.Scan(&it.ProductID, &it.Quantity, &it.Price)
		total += it.Price * float64(it.Quantity)
		items = append(items, it)
	}
	rows.Close()

	if len(items) == 0 {
		writeError(w, 400, "cart empty")
		return
	}

	bumpDBQuery("INSERT INTO orders")
	var orderID int
	err = tx.QueryRow(
		"INSERT INTO orders (user_id, total, status) VALUES ($1, $2, 'pending') RETURNING id",
		req.UserID, total,
	).Scan(&orderID)
	if err != nil {
		writeError(w, 500, "order insert failed")
		return
	}

	for _, it := range items {
		bumpDBQuery("INSERT INTO order_items")
		_, err = tx.Exec(
			"INSERT INTO order_items (order_id, product_id, quantity, price) VALUES ($1, $2, $3, $4)",
			orderID, it.ProductID, it.Quantity, it.Price,
		)
		if err != nil {
			writeError(w, 500, "order_item insert failed")
			return
		}
	}

	bumpDBQuery("DELETE FROM carts WHERE user")
	_, err = tx.Exec("DELETE FROM carts WHERE user_id=$1", req.UserID)
	if err != nil {
		writeError(w, 500, "cart clear failed")
		return
	}

	bumpDBQuery("COMMIT transaction")
	if err := tx.Commit(); err != nil {
		writeError(w, 500, "commit failed")
		return
	}

	writeJSON(w, 201, map[string]interface{}{
		"order_id": orderID,
		"total":    total,
		"status":   "pending",
	})
}

func ordersHandler(w http.ResponseWriter, r *http.Request) {
	enableCORS(w)
	if r.Method == "OPTIONS" {
		return
	}
	if !bumpRequest("/api/orders") {
		writeError(w, 503, "backend shutting down")
		return
	}
	uidStr := r.URL.Query().Get("user_id")
	uid, _ := strconv.Atoi(uidStr)
	bumpDBQuery("SELECT orders WHERE user")
	rows, err := db.Query(
		"SELECT id, user_id, total, status, created_at::text FROM orders WHERE user_id=$1 ORDER BY id DESC",
		uid,
	)
	if err != nil {
		writeError(w, 500, "query failed")
		return
	}
	defer rows.Close()
	var items []Order
	for rows.Next() {
		var o Order
		rows.Scan(&o.ID, &o.UserID, &o.Total, &o.Status, &o.CreatedAt)
		items = append(items, o)
	}
	writeJSON(w, 200, items)
}

func healthHandler(w http.ResponseWriter, r *http.Request) {
	enableCORS(w)
	if err := db.Ping(); err != nil {
		writeError(w, 503, "db unreachable")
		return
	}
	writeJSON(w, 200, map[string]string{"status": "ok"})
}

func metricsHandler(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "text/plain")
	fmt.Fprintf(w, "# HELP backend_request_count Total requests seen by this instance\n")
	fmt.Fprintf(w, "# TYPE backend_request_count counter\n")
	fmt.Fprintf(w, "backend_request_count{instance=\"%s\"} %d\n", instanceName, atomic.LoadInt64(&requestCount))
	fmt.Fprintf(w, "# HELP backend_db_query_count Total DB queries issued by this instance\n")
	fmt.Fprintf(w, "# TYPE backend_db_query_count counter\n")
	fmt.Fprintf(w, "backend_db_query_count{instance=\"%s\"} %d\n", instanceName, atomic.LoadInt64(&dbQueryCount))
}

// ---- Main ----

func main() {
	connStr := os.Getenv("DB_URL")
	if connStr == "" {
		connStr = "host=pgbouncer port=6432 dbname=ecommerce_db user=ecommerce_user password=ecommerce_pass sslmode=disable"
	}

	var err error
	db, err = sql.Open("postgres", connStr)
	if err != nil {
		log.Fatalf("db open: %v", err)
	}
	if err := db.Ping(); err != nil {
		log.Fatalf("db ping: %v", err)
	}
	log.Println("Connected to PostgreSQL")

	logEvent("BACKEND", instanceName, "started", "INFO",
		"backend instance started",
		"threshold_request", fmt.Sprintf("%d", requestThreshold),
		"threshold_db", fmt.Sprintf("%d", dbThreshold))

	http.HandleFunc("/api/register", registerHandler)
	http.HandleFunc("/api/login", loginHandler)
	http.HandleFunc("/api/products", productsHandler)
	http.HandleFunc("/api/cart/", removeCartHandler)
	http.HandleFunc("/api/cart", cartHandler)
	http.HandleFunc("/api/order", orderHandler)
	http.HandleFunc("/api/orders", ordersHandler)
	http.HandleFunc("/api/health", healthHandler)
	http.HandleFunc("/metrics", metricsHandler)

	addr := "0.0.0.0:9080"
	fmt.Printf("Backend listening on http://%s (instance=%s)\n", addr, instanceName)
	log.Fatal(http.ListenAndServe(addr, nil))
}