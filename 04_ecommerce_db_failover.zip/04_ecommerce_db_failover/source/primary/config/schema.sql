-- Initialization schema for primary PostgreSQL node
DO $$
BEGIN
    IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = 'ecommerce_user') THEN
        CREATE ROLE ecommerce_user WITH LOGIN PASSWORD 'ecommerce_pass';
    END IF;
    IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = 'replicator') THEN
        CREATE ROLE replicator WITH REPLICATION LOGIN PASSWORD 'replicator_pass';
    END IF;
END
$$;

SELECT 'CREATE DATABASE ecommerce_db OWNER ecommerce_user'
WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = 'ecommerce_db')\gexec

GRANT ALL PRIVILEGES ON DATABASE ecommerce_db TO ecommerce_user;

\c ecommerce_db

CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS products (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    price NUMERIC(10,2) NOT NULL,
    stock INTEGER NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS carts (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id),
    product_id INTEGER REFERENCES products(id),
    quantity INTEGER NOT NULL DEFAULT 1,
    added_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS orders (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id),
    total NUMERIC(10,2) NOT NULL,
    status VARCHAR(20) DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS order_items (
    id SERIAL PRIMARY KEY,
    order_id INTEGER REFERENCES orders(id),
    product_id INTEGER REFERENCES products(id),
    quantity INTEGER NOT NULL,
    price NUMERIC(10,2) NOT NULL
);

INSERT INTO users (email, password_hash) VALUES
('alice@test.com', 'hash_alice'),
('bob@test.com', 'hash_bob'),
('charlie@test.com', 'hash_charlie'),
('diana@test.com', 'hash_diana'),
('eve@test.com', 'hash_eve')
ON CONFLICT (email) DO NOTHING;

INSERT INTO products (name, description, price, stock) VALUES
('iPhone 15', 'Latest Apple phone', 79999.00, 50),
('Samsung Galaxy S24', 'Flagship Android', 74999.00, 40),
('Sony Headphones', 'Noise cancelling', 24999.00, 100),
('Dell Laptop', 'i7 16GB RAM', 65999.00, 30),
('Logitech Mouse', 'Wireless', 1499.00, 200),
('Mechanical Keyboard', 'RGB backlit', 4999.00, 150),
('USB-C Hub', '7 in 1', 2999.00, 80),
('Webcam HD', '1080p', 3499.00, 60),
('Monitor 24 inch', 'IPS panel', 12999.00, 25),
('External SSD 1TB', 'USB 3.2', 8999.00, 70)
ON CONFLICT DO NOTHING;

GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO ecommerce_user;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO ecommerce_user;
