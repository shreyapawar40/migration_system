#!/usr/bin/env python3
import time
import subprocess
import requests
from datetime import datetime

PROM = "http://prometheus:9090"
PUSHGATEWAY = "http://pushgateway:9091"
CHECK_INTERVAL = 2
DB_QUERY_THRESHOLD = 9


def log_event(layer, instance, event_type, level, message, **kv):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
    parts = [ts, layer, instance, event_type, level, message]
    if kv:
        parts.append(" ".join(f"{k}={v}" for k, v in kv.items()))
    line = " | ".join(parts)
    print(line, flush=True)
    try:
        with open("/logs/cascade.log", "a") as f:
            f.write(line + "\n")
    except Exception as e:
        print(f"log write error: {e}", flush=True)


def query_prom(expr):
    try:
        r = requests.get(f"{PROM}/api/v1/query",
                         params={"query": expr}, timeout=3)
        data = r.json()
        return data.get("data", {}).get("result", [])
    except Exception as e:
        print(f"prom query error: {e}", flush=True)
        return []


def push_metric(name, value):
    try:
        requests.post(
            f"{PUSHGATEWAY}/metrics/job/db_watcher",
            data=f"# TYPE {name} gauge\n{name} {value}\n"
        )
    except Exception as e:
        print(f"push error: {e}", flush=True)


def get_total_db_query_count():
    results = []
    results += query_prom('backend_db_query_count{instance="backend-primary"}')
    results += query_prom('backend_db_query_count{instance="backend-shadow"}')
    total = 0
    for r in results:
        try:
            total += int(float(r["value"][1]))
        except Exception:
            pass
    return total


def main():
    log_event("DB-WATCHER", "db-watcher", "started", "INFO",
              "DB watcher running",
              threshold=str(DB_QUERY_THRESHOLD))

    push_metric("db_watcher_active", 1)
    push_metric("db_watcher_failover_count", 0)

    failover_done = False
    last_logged_count = -1

    while True:
        count = get_total_db_query_count()

        if count != last_logged_count:
            log_event("DB-WATCHER", "db-watcher", "count_update", "INFO",
                      f"aggregate DB query count = {count}",
                      count=str(count),
                      threshold=str(DB_QUERY_THRESHOLD))
            last_logged_count = count

        if count >= DB_QUERY_THRESHOLD and not failover_done:
            log_event("DB-WATCHER", "db-watcher", "threshold_reached", "WARN",
                      "DB query threshold hit — stopping pg-primary",
                      count=str(count),
                      threshold=str(DB_QUERY_THRESHOLD))

            log_event("DB-WATCHER", "db-watcher", "stopping_primary", "CRITICAL",
                      "executing docker stop pg-primary")

            try:
                subprocess.run(["docker", "stop", "pg-primary"],
                               capture_output=True, timeout=20)
                log_event("DB-WATCHER", "db-watcher", "primary_stopped", "INFO",
                          "pg-primary stopped — orchestrator will promote standby")
            except Exception as e:
                log_event("DB-WATCHER", "db-watcher", "stop_failed", "ERROR",
                          f"failed to stop pg-primary: {e}")

            push_metric("db_watcher_failover_count", 1)
            failover_done = True

        primary_up_results = query_prom('pg_up{job="postgres-primary"}')
        if primary_up_results:
            try:
                up = int(float(primary_up_results[0]["value"][1]))
            except Exception:
                up = 0
            if up == 1 and failover_done:
                log_event("DB-WATCHER", "db-watcher", "primary_recovered", "INFO",
                          "pg-primary is back up — resetting watcher state")
                failover_done = False
                push_metric("db_watcher_failover_count", 0)

        time.sleep(CHECK_INTERVAL)


if __name__ == "__main__":
    main()