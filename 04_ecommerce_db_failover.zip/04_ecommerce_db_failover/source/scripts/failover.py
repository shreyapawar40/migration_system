#!/usr/bin/env python3
import subprocess
import time
import socket
import requests
from datetime import datetime

PRIMARY_HOST = "pg-primary"
PRIMARY_PORT = 5432
STANDBY_HOST = "pg-standby"
STANDBY_PORT = 5432
PUSHGATEWAY = "http://pushgateway:9091"
CHECK_INTERVAL = 2

def log(msg):
    print(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {msg}", flush=True)

def is_reachable(host, port):
    try:
        s = socket.create_connection((host, port), timeout=2)
        s.close()
        return True
    except Exception:
        return False

def run(cmd):
    return subprocess.run(cmd, shell=True, capture_output=True, text=True)

def push_metric(name, value, labels=""):
    url = f"{PUSHGATEWAY}/metrics/job/failover{labels}"
    data = f"# TYPE {name} gauge\n{name} {value}\n"
    try:
        r = requests.post(url, data=data)
        if r.status_code >= 300:
            log(f"Push failed: {r.status_code} {r.text}")
    except Exception as e:
        log(f"Push error: {e}")

def promote_standby():
    log("Promoting standby to primary...")
    result = run("docker exec -u postgres pg-standby pg_ctl promote -D /var/lib/postgresql/data")
    log(f"Promote result: {result.stdout.strip()} | {result.stderr.strip()}")

def repoint_pgbouncer():
    log("Repointing PgBouncer to new primary (pg-standby)...")
    cmd = (
        "docker exec pgbouncer sh -c \""
        "sed 's/host=pg-primary/host=pg-standby/g' /etc/pgbouncer/pgbouncer.ini > /tmp/pgb.ini && "
        "cat /tmp/pgb.ini > /etc/pgbouncer/pgbouncer.ini && "
        "kill -HUP 1"
        "\""
    )
    result = run(cmd)
    log(f"PgBouncer repoint: {result.stdout.strip()} | {result.stderr.strip()}")

def main():
    log("Failover orchestrator started.")
    failover_count = 0
    already_failed_over = False
    push_metric("failover_count", failover_count)

    while True:
        primary_up = is_reachable(PRIMARY_HOST, PRIMARY_PORT)

        if not primary_up and not already_failed_over:
            log("PRIMARY DOWN. Starting failover...")
            failover_count += 1
            start = time.time()

            promote_standby()
            repoint_pgbouncer()

            duration = time.time() - start
            log(f"Failover complete in {duration:.2f}s")

            push_metric("failover_count", failover_count)
            push_metric("last_failover_duration_seconds", duration)
            push_metric("last_failover_timestamp", time.time())

            already_failed_over = True
            log("Failover done. Waiting for primary to come back or standby to stabilize.")

        elif primary_up and already_failed_over:
            log("Primary is back up. Resetting failover state.")
            already_failed_over = False

        time.sleep(CHECK_INTERVAL)
        
if __name__ == "__main__":
    main()
