#!/usr/bin/env python3
import psycopg2, time, random, sys
from datetime import datetime

DB = "host=pg-primary port=5432 dbname=ecommerce_db user=ecommerce_user password=ecommerce_pass"

def log(m):
    print(f"[{datetime.now().strftime('%H:%M:%S')}] {m}", flush=True)

while True:
    try:
        conn = psycopg2.connect(DB)
        conn.autocommit = True
        cur = conn.cursor()
        while True:
            user_id = random.randint(1, 5)
            product_id = random.randint(1, 10)
            qty = random.randint(1, 3)
            cur.execute("INSERT INTO carts (user_id, product_id, quantity) VALUES (%s, %s, %s)",
                        (user_id, product_id, qty))
            cur.execute("""INSERT INTO orders (user_id, total, status)
                           VALUES (%s, %s, 'pending') RETURNING id""",
                        (user_id, qty * 100))
            order_id = cur.fetchone()[0]
            cur.execute("""INSERT INTO order_items (order_id, product_id, quantity, price)
                           VALUES (%s, %s, %s, %s)""",
                        (order_id, product_id, qty, 100))
            log(f"order placed #{order_id}")
            time.sleep(0.5)
    except Exception as e:
        log(f"DB error: {e}")
        time.sleep(2)
