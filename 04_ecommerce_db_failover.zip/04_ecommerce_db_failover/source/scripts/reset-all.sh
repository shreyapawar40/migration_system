#!/bin/bash
set -e
cd ~/ecommerce-db

echo "======================================"
echo "=== Full reset for next demo ==="
echo "======================================"

# ---------- DB RESET ----------
echo ""
echo "=== [DB] Stopping DB stack ==="
docker stop pg-primary pg-standby 2>/dev/null || true

echo "=== [DB] Removing standby container and volume ==="
docker compose rm -f pg-standby 2>/dev/null || true
docker volume rm pg-standby-data 2>/dev/null || true
docker volume create pg-standby-data

echo "=== [DB] Starting primary ==="
docker start pg-primary
sleep 8

echo "=== [DB] Taking base backup ==="
docker run --rm --network ecommerce-db_dbnet \
  -v pg-standby-data:/var/lib/postgresql/data \
  -e PGPASSWORD=replicator_pass \
  postgres:16 \
  bash -c "chown -R postgres:postgres /var/lib/postgresql/data && su postgres -c 'pg_basebackup -h pg-primary -U replicator -D /var/lib/postgresql/data -Fp -Xs -P -R'"

echo "=== [DB] Starting standby ==="
docker compose up -d pg-standby
sleep 10

echo "=== [DB] Repointing PgBouncer to primary ==="
docker exec pgbouncer sh -c "sed 's/host=pg-standby/host=pg-primary/g' /etc/pgbouncer/pgbouncer.ini > /tmp/pgb.ini && cat /tmp/pgb.ini > /etc/pgbouncer/pgbouncer.ini && kill -HUP 1"
docker restart pgbouncer
sleep 3

echo "=== [DB] Restarting DB failover orchestrator ==="
docker restart failover
sleep 5
# ---------- SERVER RESET ----------
echo ""
echo "=== [SERVER] Recreating backend containers (fresh DB connections) ==="
docker compose up -d --force-recreate backend-primary backend-shadow
sleep 5

echo "=== [SERVER] Pointing Nginx back to backend-primary ==="
docker exec nginx sh -c "sed 's/server backend-shadow:9080/server backend-primary:9080/' /etc/nginx/nginx.conf > /tmp/nginx.conf && cat /tmp/nginx.conf > /etc/nginx/nginx.conf && nginx -s reload"
sleep 2

echo "=== [SERVER] Restarting server failover orchestrator ==="
docker restart server-failover
sleep 5

# ---------- LOGS RESET ----------
echo ""
echo "=== [LOGS] Rotating cascade log ==="
if [ -f ~/ecommerce-db/logs/cascade.log ]; then
  mv ~/ecommerce-db/logs/cascade.log ~/ecommerce-db/logs/cascade-$(date +%s).log
fi
touch ~/ecommerce-db/logs/cascade.log
chmod 666 ~/ecommerce-db/logs/cascade.log

# ---------- HEALTH CHECK ----------
echo ""
echo "======================================"
echo "=== VERIFICATION ==="
echo "======================================"

echo ""
echo "--- Standby recovery state (expect 't') ---"
docker exec -it pg-standby psql -U postgres -c "SELECT pg_is_in_recovery();"

echo ""
echo "--- Replication status (expect 1 streaming row) ---"
docker exec -it pg-primary psql -U postgres -c "SELECT client_addr, state FROM pg_stat_replication;"

echo ""
echo "--- PgBouncer target (expect host=pg-primary) ---"
docker exec pgbouncer sh -c "grep 'host=' /etc/pgbouncer/pgbouncer.ini"

echo ""
echo "--- Nginx upstream (expect backend-primary) ---"
docker exec nginx sh -c "grep 'server backend' /etc/nginx/nginx.conf"

echo ""
echo "--- Backend health through Nginx ---"
curl -s http://localhost:8000/api/health
echo ""

echo ""
echo "======================================"
echo "=== Reset complete. Ready for demo. ==="
echo "======================================"