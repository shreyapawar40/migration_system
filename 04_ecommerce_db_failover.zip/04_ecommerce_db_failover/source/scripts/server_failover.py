#!/usr/bin/env python3
import time
import socket
import requests
import subprocess
from datetime import datetime

PRIMARY = ("backend-primary", 9080)
SHADOW = ("backend-shadow", 9080)
PUSHGATEWAY = "http://pushgateway:9091"
CHECK_INTERVAL = 2

def log(msg):
    print(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {msg}", flush=True)

def is_reachable(host, port):
    try:
        s = socket.create_connection((host, port), timeout=2)
        s.close()
        return True
    except Exception:
        return False

def run(cmd):
    return subprocess.run(cmd, shell=True, capture_output=True, text=True)

def push_metric(name, value):
    url = f"{PUSHGATEWAY}/metrics/job/server_failover"
    data = f"# TYPE {name} gauge\n{name} {value}\n"
    try:
        requests.post(url, data=data)
    except Exception as e:
        log(f"Push error: {e}")

def switch_nginx_to_shadow():
    log("Switching Nginx upstream to backend-shadow...")
    script = (
        "sed 's/server backend-primary:9080/server backend-shadow:9080/' "
        "/etc/nginx/nginx.conf > /tmp/nginx.conf && "
        "cat /tmp/nginx.conf > /etc/nginx/nginx.conf && "
        "nginx -s reload"
    )
    result = run(f"docker exec nginx sh -c \"{script}\"")
    log(f"Nginx switch: {result.stdout.strip()} | {result.stderr.strip()}")

def switch_nginx_to_primary():
    log("Switching Nginx upstream back to backend-primary...")
    script = (
        "sed 's/server backend-shadow:9080/server backend-primary:9080/' "
        "/etc/nginx/nginx.conf > /tmp/nginx.conf && "
        "cat /tmp/nginx.conf > /etc/nginx/nginx.conf && "
        "nginx -s reload"
    )
    result = run(f"docker exec nginx sh -c \"{script}\"")
    log(f"Nginx failback switch: {result.stdout.strip()} | {result.stderr.strip()}")

def main():
    log("Server failover orchestrator started.")
    failover_count = 0
    already_failed_over = False
    push_metric("server_failover_count", failover_count)

    while True:
        primary_up = is_reachable(*PRIMARY)

        if not primary_up and not already_failed_over:
            log("BACKEND-PRIMARY DOWN. Starting server failover...")
            failover_count += 1
            start = time.time()

            switch_nginx_to_shadow()

            duration = time.time() - start
            log(f"Server failover complete in {duration:.2f}s")

            push_metric("server_failover_count", failover_count)
            push_metric("last_server_failover_duration_seconds", duration)
            push_metric("last_server_failover_timestamp", time.time())

            already_failed_over = True

        elif primary_up and already_failed_over:
            log("Backend-primary is back up. Restoring Nginx to primary (failback)...")
            switch_nginx_to_primary()
            already_failed_over = False

        time.sleep(CHECK_INTERVAL)

if __name__ == "__main__":
    main()
