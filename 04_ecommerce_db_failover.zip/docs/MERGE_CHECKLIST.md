# Merge and final-demo checklist

## Packaging checklist
- [x] Keep controller and worker as separate Go modules.
- [x] Keep CRIU experiment separate from the baseline recovery path.
- [x] Keep Redis rate limiter in its own folder.
- [x] Keep e-commerce/database failover stack in its own folder.
- [x] Add root README and objective status checklist.
- [x] Exclude prebuilt `.exe` binaries from the bundle.

## Integration and reliability checklist — still required
- [ ] Choose and document the authoritative shared architecture and service boundaries.
- [ ] Fix dependency/build configuration for the Redis rate limiter (module files and required environment values).
- [ ] Fix e-commerce backend image build/startup and automate PostgreSQL standby bootstrap/replication.
- [ ] Correct and test Nginx primary-to-shadow routing and failback behavior.
- [ ] Integrate CRIU dump/restore with failure detection and recovery manager on a compatible Linux environment.
- [ ] Verify restored process/application state, not only that a replacement container is running.
- [ ] Test failures: worker disconnect, service crash, backend crash, primary database failure, Redis/rate-limiter primary failure.
- [ ] Test cross-machine networking, target readiness and recovery retry behavior.
- [ ] Add authentication or restrict the controller protocol to a trusted lab network.
- [ ] Record downtime, recovery time, CPU and memory use for repeated runs.
- [ ] Create dashboard view showing detected failure, chosen target, recovery status, and measured metrics.
- [ ] Capture final-demo evidence/logs and document exact commands used.

## Acceptance rule
Mark a checkbox complete only after running the test and saving the output/logs. File presence alone does not count as a passed test.
