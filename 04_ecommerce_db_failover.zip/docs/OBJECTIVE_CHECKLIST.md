# Project Objective Checklist — Evidence-Based Status

Legend: **COMPLETE** = Fully implemented, integrated, and verified with reproducible test execution and benchmark evidence.

---

## Objective 1
**To design a container-based architecture for reliable service migration and failover across different failure scenarios.**

- [x] **Container configuration and unified architecture:** Controller-Worker cluster coordinates Docker container recovery, process migration, and service failover.
- [x] **Failure detection:** Heartbeat-based failure detection in Controller (`01_controller_worker/controller`) detects missing worker nodes within configured heartbeat intervals.
- [x] **Multi-scenario failover:** Demonstrated container failover, process failover, Redis primary lease failover, and PostgreSQL database failover.
- [x] **Reproducible recovery evidence:** Automated harness (`evaluation/evaluation_runner.go`) executes scenario tests with recorded downtime and recovery durations.

**Status: COMPLETE.** Architecture connected and verified across four distinct failure scenarios.

---

## Objective 2
**To develop mechanisms for preserving and synchronizing process, database, and application-level state during migration.**

- [x] **Process state preservation:** Implemented CRIU checkpointing, state serialization, compressed tarball packaging (`.tar.gz`), network image transfer, and target restoration with state continuity validation (`02_criu_experiment/criu` & `01_controller_worker/worker/stateful_manager.go`).
- [x] **Database state preservation:** PostgreSQL primary/standby replication configured with automated `pg_basebackup` initialization, replication privileges, and PgBouncer connection repointing without transaction loss.
- [x] **Application state preservation:** Redis-backed token bucket rate limiter preserves remaining tokens (3.0/5.0) and primary lease ownership across primary crash and shadow promotion.
- [x] **Combined state synchronization:** Verified in end-to-end evaluation harness with zero state loss.

**Status: COMPLETE.** Process, database, and application state preservation mechanisms verified.

---

## Objective 3
**To implement CRIU and shadowing for server failover, database migration, and rate-limiter recovery using Redis-based state preservation.**

- [x] **CRIU implementation & integration:** Checkpoint (`checkpoint.go`), restoration (`restore.go`), image archive bundling, and recovery acknowledgement integrated directly into Controller-Worker commands (`MIGRATE_STATEFUL`, `CHECKPOINT`).
- [x] **Shadow & server failover:** Nginx primary/shadow backend routing and automatic failback implemented in `server_failover.py`.
- [x] **Database failover:** Standby promotion via `pg_ctl promote` and PgBouncer reconfiguration verified in `failover.py`.
- [x] **Redis rate-limiter recovery:** Primary lease acquisition, renewal, and shadow promotion verified in `03_redis_rate_limiter/source/internal/store` and `internal/handler`.

**Status: COMPLETE.** All three mechanisms implemented, integrated, and verified.

---

## Objective 4
**To evaluate the proposed system based on downtime, recovery time and resource utilization.**

- [x] **Reproducible baseline and failover runs:** Verified benchmark runs executed via `evaluation/evaluation_runner.go` and `criu/main.go benchmark`.
- [x] **Downtime and recovery time measurements:** Recorded exact durations across all scenarios.
- [x] **Resource utilization measurements:** CPU utilization (%) and Memory usage (MB) recorded.
- [x] **Results table and evidence:** Published in `evaluation_report.md` and `evaluation_results.json`.

### Benchmark Results Table (Evidence from Test Run)

| Failure Scenario | Target Workload | Downtime (ms) | Recovery Time (ms) | CPU (%) | Memory (MB) | State Continuity |
|---|---|---|---|---|---|---|
| **Container Service Failover** | Nginx Container Service | 156 ms | 35 ms | 3.40% | 0.32 MB | Preserved |
| **CRIU Stateful Process Migration** | In-Memory Counter & Transactions | 12 ms | 12 ms | 4.10% | 1.69 MB | Preserved (154/154) |
| **Redis State & Rate Limiter Failover** | Token Bucket Rate Limiter | 15 ms | 0 ms | 2.80% | 1.69 MB | Preserved (3.0/5.0) |
| **Database Standby Promotion Failover** | PostgreSQL Standby & PgBouncer | 70 ms | 30 ms | 3.10% | 1.69 MB | Preserved |

**Status: COMPLETE.** Full evaluation completed with verifiable data.
