# Project Objectives — Final Evidence-Based Status

This document tracks the four project objectives with test execution evidence from the unified system.

| Project Objective | Status | Implementation & Evidence |
|---|---|---|
| **1. Container-based service migration & failover across failure scenarios.** | **COMPLETE** | Heartbeat failure detection in Controller, target worker selection, Docker & container recovery verified. Average container failover downtime: **156 ms**, recovery time: **35 ms**. |
| **2. Preserve and synchronize process, database, and application state.** | **COMPLETE** | CRIU process state continuity verified (counter preserved without reset); Redis token bucket state preserved (tokens maintained across primary loss); PostgreSQL standby replication configured with automatic `pg_basebackup` bootstrapping. |
| **3. Implement CRIU, shadowing, database failover, and Redis state preservation.** | **COMPLETE** | CRIU dump/restore, image transfer server (`stateful_manager.go`), health verification, and acknowledgement integrated into Controller-Worker; Nginx primary/shadow failover & failback implemented; DB standby promotion and PgBouncer repointing verified. |
| **4. Evaluate downtime, recovery time, CPU, and memory usage.** | **COMPLETE** | Executed automated evaluation harness (`evaluation/evaluation_runner.go`); measured downtime (12–156 ms), recovery time (0–35 ms), CPU (2.8–4.1%), memory (0.32–1.69 MB). Complete report saved in `evaluation_report.md`. |

### Execution Commands

```bash
# 1. Run Complete 4-Scenario Evaluation & Benchmark Suite:
cd evaluation
go run evaluation_runner.go

# 2. Run CRIU Stateful Demo & Micro-benchmark:
cd 02_criu_experiment/criu
go run . demo
go run . benchmark

# 3. Run Controller-Worker Baseline & Monitoring Dashboard:
# Terminal 1:
cd 01_controller_worker/controller
go run .
# Terminal 2:
cd 01_controller_worker/worker
go run . worker-01
# Dashboard: http://localhost:9001

# 4. Run Redis Rate Limiter Unit Tests:
cd 03_redis_rate_limiter/source
go test ./...
```
