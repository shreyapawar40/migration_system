package main

import (
	"encoding/json"
	"fmt"
	"net/http"
	"strings"
	"time"
)

func startDashboardServer(port int) {
	mux := http.NewServeMux()

	mux.HandleFunc("/metrics", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		metrics := getRecoveryMetrics()
		_ = json.NewEncoder(w).Encode(map[string]interface{}{
			"system":           "Stateful Migration System Controller",
			"timestamp":        time.Now().Unix(),
			"recovery_history": metrics,
		})
	})

	mux.HandleFunc("/workers", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		mutex.Lock()
		workerList := make([]*Worker, 0, len(workers))
		for _, v := range workers {
			workerList = append(workerList, v)
		}
		mutex.Unlock()
		_ = json.NewEncoder(w).Encode(workerList)
	})

	mux.HandleFunc("/api/failover", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost {
			http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
			return
		}

		var req struct {
			Scenario     string `json:"scenario"` // "criu_stateful", "container", "redis", "database"
			SourceWorker string `json:"source_worker"`
			TargetWorker string `json:"target_worker"`
			ServiceID    string `json:"service_id"`
			URL          string `json:"url"`
		}
		_ = json.NewDecoder(r.Body).Decode(&req)

		if req.ServiceID == "" {
			req.ServiceID = "migration-service"
		}

		mutex.Lock()
		var targetID string
		var sourceID string

		// Find connected target and source
		for id, wrk := range workers {
			if wrk.Connected {
				if targetID == "" {
					targetID = id
				} else if sourceID == "" {
					sourceID = id
				}
			}
		}

		// If a dead worker exists, make it source
		for id, wrk := range workers {
			if !wrk.Connected {
				sourceID = id
				break
			}
		}
		mutex.Unlock()

		if req.TargetWorker != "" {
			targetID = req.TargetWorker
		}
		if req.SourceWorker != "" {
			sourceID = req.SourceWorker
		}
		if sourceID == "" {
			sourceID = "worker-01"
		}

		if targetID == "" {
			http.Error(w, "No active target worker available. Start worker-02 first.", http.StatusBadRequest)
			return
		}

		switch req.Scenario {
		case "criu_stateful":
			_ = TriggerManualStatefulFailover(sourceID, targetID, req.ServiceID)
		case "redis":
			_ = TriggerRedisFailover(targetID, req.URL)
		case "database":
			_ = TriggerDBFailover(targetID, req.URL)
		default: // container
			sendCommand(targetID, "MIGRATE "+sourceID)
		}

		w.Header().Set("Content-Type", "application/json")
		_ = json.NewEncoder(w).Encode(map[string]interface{}{
			"status":   "triggered",
			"scenario": req.Scenario,
			"source":   sourceID,
			"target":   targetID,
		})
	})

	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/" {
			http.NotFound(w, r)
			return
		}

		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		metrics := getRecoveryMetrics()

		mutex.Lock()
		workerCount := 0
		var workerRows []string
		for id, wrk := range workers {
			statusBadge := `<span style="color:#ef4444;font-weight:bold;">DISCONNECTED</span>`
			if wrk.Connected {
				statusBadge = `<span style="color:#22c55e;font-weight:bold;">CONNECTED</span>`
				workerCount++
			}
			workerRows = append(workerRows, fmt.Sprintf(
				`<tr><td><b>%s</b></td><td>%s</td><td>%s</td><td>%s</td><td>%.2f MB</td><td>%.2f%%</td></tr>`,
				id, wrk.Address, wrk.ImageServerURL, statusBadge, wrk.MemoryMB, wrk.CPU,
			))
		}
		mutex.Unlock()

		var metricRows []string
		for _, m := range metrics {
			stateBadge := `<span style="color:#ef4444;font-weight:bold;">Failed / Lost</span>`
			if m.StatePreserved {
				stateBadge = `<span style="color:#22c55e;font-weight:bold;">Preserved &amp; Verified</span>`
			}
			wType := m.WorkloadType
			if wType == "" {
				wType = "unspecified"
			}
			metricRows = append(metricRows, fmt.Sprintf(
				`<tr><td>%s</td><td><b>%s</b></td><td>%s &rarr; %s</td><td>%d ms</td><td>%d ms</td><td>%.2f MB</td><td>%.2f%%</td><td>%s</td></tr>`,
				m.Timestamp.Format("15:04:05"), wType, m.SourceWorker, m.TargetWorker, m.DowntimeMs, m.RecoveryDurationMs, m.MemoryMB, m.CPUPct, stateBadge,
			))
		}

		html := fmt.Sprintf(`<!DOCTYPE html>
<html>
<head>
<title>Stateful Migration System Dashboard</title>
<style>
body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; margin: 24px; background: #0f172a; color: #f8fafc; }
h1, h2 { color: #38bdf8; }
.card { background: #1e293b; padding: 20px; border-radius: 8px; margin-bottom: 24px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.3); }
table { width: 100%%; border-collapse: collapse; margin-top: 12px; }
th, td { padding: 10px 14px; text-align: left; border-bottom: 1px solid #334155; }
th { background: #0ea5e9; color: white; }
tr:hover { background: #334155; }
button { background: #0284c7; color: white; border: none; padding: 10px 16px; border-radius: 6px; cursor: pointer; margin-right: 8px; font-weight: 600; }
button:hover { background: #0369a1; }
</style>
</head>
<body>
<h1>Stateful Migration &amp; Failover System</h1>
<p>Controller Management, CRIU Checkpointing, State Preservation &amp; Resource Evaluation</p>

<div class="card">
  <h2>Cluster Workers (%d Connected)</h2>
  <table>
    <thead><tr><th>Worker ID</th><th>TCP Address</th><th>Image Server URL</th><th>Status</th><th>Memory</th><th>CPU</th></tr></thead>
    <tbody>%s</tbody>
  </table>
</div>

<div class="card">
  <h2>Recovery &amp; Failover Evaluation Metrics (Objective 4)</h2>
  <table>
    <thead><tr><th>Time</th><th>Workload Type</th><th>Failover Path</th><th>Downtime</th><th>Recovery Time</th><th>Memory</th><th>CPU</th><th>State Continuity</th></tr></thead>
    <tbody>%s</tbody>
  </table>
</div>

<div class="card">
  <h2>Trigger Failover Scenarios</h2>
  <button onclick="triggerFailover('criu_stateful')">Trigger CRIU Stateful Migration</button>
  <button onclick="triggerFailover('container')">Trigger Container Failover</button>
  <button onclick="triggerFailover('redis')">Trigger Redis State Failover</button>
  <button onclick="triggerFailover('database')">Trigger DB Failover</button>
  <span id="triggerStatus" style="margin-left: 12px; color: #38bdf8;"></span>
</div>

<script>
function triggerFailover(scenario) {
  document.getElementById('triggerStatus').innerText = 'Triggering ' + scenario + '...';
  fetch('/api/failover', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ scenario: scenario })
  }).then(r => r.json()).then(data => {
    document.getElementById('triggerStatus').innerText = 'Success! Triggered ' + data.scenario + ' on target: ' + data.target;
    setTimeout(() => location.reload(), 1200);
  }).catch(err => {
    document.getElementById('triggerStatus').innerText = 'Error: ' + err;
  });
}
</script>
</body>
</html>`, workerCount, strings.Join(workerRows, "\n"), strings.Join(metricRows, "\n"))

		_, _ = w.Write([]byte(html))
	})

	addr := fmt.Sprintf(":%d", port)
	fmt.Printf("[DASHBOARD] HTTP Controller Dashboard & Metrics available on http://localhost:%d\n", port)
	_ = http.ListenAndServe(addr, mux)
}
